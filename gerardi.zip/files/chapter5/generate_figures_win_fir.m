function generate_figures_win_fir

% Generate plots for pp. 5-24.

% ------------------------------------------------------------------------------
%                           Effect of Window Length
% ------------------------------------------------------------------------------

% Generate FIR filter coefficients.
b21 = fir1(20, 0.25);
b51 = fir1(50, 0.25);

% Time-domain plot.
figure(1)
clf
stem(0:20, b21, 'b');
hold on
stem(0:50, b51, 'g');
title('Impulse Response');
xlabel('Samples');
ylabel('Amplitude');
legend('Window length 21', 'Window length 51');

% Frequency-domain plot.
figure(2)
clf
N = 8192;
f = (-0.5) : (1/N) : (((N/2) - 1) / N);
plot(2*f, fftshift(20*log10(abs(fft(b21,N)))), 'b')
hold on
plot(2*f, fftshift(20*log10(abs(fft(b51,N)))), 'g')
title('Magnitude Response (dB)');
xlabel('Normalized Frequency (x\pi rad/sample)');
ylabel('Magnitude (dB)');
axis([-0.05 1.05 -80 10])
legend('Window length 21', 'Window length 51');


% ------------------------------------------------------------------------------
%                           Effect of Window Length
% ------------------------------------------------------------------------------

% Generate FIR filter coefficients.
brect    = fir1(50, 0.25, ones(51,1));
bhamming = fir1(50, 0.25, hamming(51));

% Frequency-domain plot.
figure(3)
clf
N = 8192;
f = (-0.5) : (1/N) : (((N/2) - 1) / N);
plot(2*f, fftshift(20*log10(abs(fft(bhamming,N)))), 'b')
hold on
plot(2*f, fftshift(20*log10(abs(fft(brect,N)))), 'g')
title('Magnitude Response (dB)');
xlabel('Normalized Frequency (x\pi rad/sample)');
ylabel('Magnitude (dB)');
axis([0 0.3 -20 2])
legend('Hamming Window', 'Rectangular Window');

end

