%% Computation of PSD through direct FFT, periodogram() and pwelch()
Fs = 100; % Sampling rate
t = 0:1/Fs:10-1/Fs; % Array of time indices for 10 seconds
% Set DFT length
ndft = 1024;
% Create a signal that is a sum of two sinusoids.
% Remember that the power of a sinusoid of amplitude "A" is (A^2)/2.
% Experiment with different amplitudes to test.
a1 = 2.0;
a2 = 1.0;
y = a1*sin(2*pi*15*t) + a2*sin(2*pi*30*t);
%% Compute PSD Directly from FFT
Y = fft(y,ndft);
% Generate the frequency vector at which DFT is computed
f = Fs*(0:ndft-1)/ndft;
% Compute energy spectral density (for the finite length signal)
ESD = Y.*conj(Y)/ndft;
figure(1); plot(f,ESD)
title('Periodogram');
% Compute PSD using the periodogram() function
[Pxx,fp] = periodogram(y,[],ndft,Fs); % Compare with the periodogram function
hold on; plot(fp, (Pxx/2)*length(y)*(Fs/ndft), 'r');
% Compute PSD using the pwelch() function
[Pww,fw] = pwelch(y,[],[],ndft,Fs); % Compare with pwelch function
plot(fp, (Pww/2)*length(y)*(Fs/ndft), 'g'); hold off;
%% Compute theoretical signal powers
% Compute powers of the two sinusoids that we added (power of a sinusoid
% with amplitude A is A^2/2)
format compact;
signal_pwr_15Hz = a1^2/2
signal_pwr_30Hz = a2^2/2
signal_tot_pwr = signal_pwr_15Hz + signal_pwr_30Hz
%% First check total power from all methods agree with each other
% Total power using direct FFT computation
measured_totpwrFFT = sum(ESD)/length(y)
% Total power using the periodogram() function. Notice the (Fs/ndft)
% multiplier for the integration approximation.
measured_totpwrPeriodogram = sum(Pxx)*Fs/ndft
% Total power using the pwelch() function. Notice the (Fs/ndft)
% multiplier for the integration approximation.
measured_totpwrWelch = sum(Pww)*Fs/ndft
%% Measure signal power for each sinusoid
% Remember that the power of each sinusoid is split into two parts,
% one at +f and another at -f. So, expect to see half the power for each
% peak. Therefore we multiply the sum around one peak by 2. Also we compute
% power from energy by dividing by length of signal.
%
% First, for the 15 Hz sinusoid --
% Compute 15 Hz power using direct FFT
indx15Hz = find(f > 10 & f < 20);
measured_pwr15Hz_FFT = 2 * sum(ESD(indx15Hz))/length(y)
% Compute 15 Hz power using periodogram() function, we don't need to
% multiply by 2 here since the periodogram() function does this
% automaticlly for real valued signals. Notice the (Fs/ndft)
% multiplier for the integration approximation.
indx15Hz = find(fp > 10 & fp < 20);
measured_pwr15Hz_periodogram = sum(Pxx(indx15Hz))*Fs/ndft
% Compute 15 Hz power using pwelch() function, we don't need to
% multiply by 2 here since the pwelch() function does this
% automaticlly for real valued signals. Notice the (Fs/ndft)
% multiplier for the integration approximation.
indx15Hz = find(fw > 10 & fw < 20);
measured_pwr15Hz_pwelch = sum(Pww(indx15Hz))*Fs/ndft
%% Now for the 30 Hz sinusoid --
indx30Hz = find(f > 25 & f < 35);
measured_pwr30Hz_FFT = 2 * sum(ESD(indx30Hz))/length(y)
indx30Hz = find(fp > 25 & fp < 35);
measured_pwr30Hz_periodogram = sum(Pxx(indx30Hz))*Fs/ndft
indx30Hz = find(fw > 25 & fw < 35);
measured_pwr30Hz_pwelch = sum(Pww(indx30Hz))*Fs/ndft
