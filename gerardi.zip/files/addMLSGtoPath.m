
function addMLSGtoPath

rootDir = fileparts(which('addMLSGtoPath'));

path2add{1} = rootDir;

path2add{2} = [rootDir,'\chapter2'];

path2add{3} = [rootDir,'\chapter3'];

path2add{4} = [rootDir,'\chapter4'];

path2add{5} = [rootDir,'\chapter5'];

path2add{6} = [rootDir,'\chapter6'];

path2add{7} = [rootDir,'\chapter7'];

path2add{8} = [rootDir,'\chapter8'];

path2add{9} = [rootDir,'\exercises\chapter2'];

path2add{10} = [rootDir,'\exercises\chapter3'];

path2add{11} = [rootDir,'\exercises\chapter4'];

path2add{12} = [rootDir,'\exercises\chapter5'];

path2add{13} = [rootDir,'\exercises\chapter6'];

path2add{14} = [rootDir,'\exercises\chapter7'];

path2add{15} = [rootDir,'\exercises\chapter8'];


platform = computer;
if (~any(strcmp(platform,{'PCWIN','PCWIN64'})))
    for i = 1:length(path2add)
        path2add{i}(path2add{i} == '\') = '/';
    end
end

for i = 1:length(path2add)
    addpath(path2add{i},'-end');
end

