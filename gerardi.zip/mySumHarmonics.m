function [y, t] = mySumHarmonics(f0, nHarmonics)

oddNums = 1:2:(2*nHarmonics-1);
A       = 1./oddNums;
f       = (f0*oddNums).';
fs      = 3*max(f);


t = 0 : 1/fs : 3/f0;

x = zeros(size(t));
for i=1:nHarmonics
    x = x + A(i) * sin(2*pi*f(i)*t);
end
plot (t,x);

end
