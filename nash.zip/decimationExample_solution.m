%% Clear all variables.
clear

%% Create single tone signal.
t = (0 : 1e5) / 100;
x = sin(2*pi*10*t);
figure(1)
clf
mypsd(x, 100);

%% Lowpass filter signal x.
h = firpm(101, [0 20 30 50]/50, [1 1 0 0]);
fvtool(h, 'Fs', 100)
x = filter(h, 1, x);
figure(3)
clf
mypsd(x, 100);

%% Keep every other sample.
y = downsample(x, 2);
figure(2)
clf
mypsd(y, 50);



