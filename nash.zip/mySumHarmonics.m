function [y, t] = mySumHarmonics(f0, nHarmonics)

oddNums = 1 : 2 : (2*nHarmonics - 1);
A       = 1 ./ oddNums;     % Row vector of amplitudes
f       = (f0 * oddNums).'; % Column vector of sine frequencies
fs      = 3 * max(f);       % Sampling rate

% TODO: Create the time vector t.
% TODO: Use a for loop to generate the sum of sine waves or you can
%       vectorize your code (i.e. no for loop).
% TODO: Plot your signal.

t  = 0 : 1/fs : 3/f0;

x  = A*sin(2*pi.*f*t);

figure(1)
plot(t,x)


end