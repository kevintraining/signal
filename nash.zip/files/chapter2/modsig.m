%% MODSIG Demonstrates modulation and demodulation.

% Load signal (radio) and sampling frequency (fs).
load radio

%% Plot and listen to the original signal
subplot(3,1,1);
plot(radio);
title('Original Signal');
sound(radio,fs);
pause(7);

%% FM carrier frequency (must be < fs/2)
fc = fs/8;
% Modulate signal and plot a section
y = modulate(radio,fc,fs,'fm');
subplot(3,1,2);
plot(y,'r');
title('Modulated Signal (Partial)');
axis([0 1e3 -1 1]);
sound(y,fs);
pause(7);

%% Demodulate, plot, and hear signal:
z = demod(y,fc,fs,'fm');
subplot(3,1,3);
plot(z,'b');
title('Demodulated Signal');
sound(z,fs);