% sineWave Creates a sine wave.

fs = 1000;      % Sampling rate in Hertz (samples/sec)
A = 1.2;        % Amplitude of sine wave
f = 2;          % Frequency in Hertz
phi = pi/8;     % Phase at time 0 in radians
duration = 2;   % Signal duration in seconds
t = 0:1/fs:duration;
sinewave = A*sin(2*pi*f*t + phi);
plot(t,sinewave)

title(['Frequency = 2 Hz',sprintf('\n'),'Notice the Phase Shift'])
ylabel('Magnitude')
xlabel('Time')