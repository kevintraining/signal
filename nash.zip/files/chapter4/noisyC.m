%% NOISYC Adds noise to middle C.

fs = 1e4;
t = 0:1/fs:2;

sw = sin(2*pi*262.62*t); % Middle C
plot(t,sw)
axis([0 0.04 -1.1 1.1])
title('\fontsize{14}{Middle C}')
soundsc(sw,fs)
pause(5)
%%
n = 0.1*randn(size(sw));
swn = sw + n;
figure
plot(t,swn)
axis([0 0.04 -1.1 1.1])
title('\fontsize{14}{Noisy Middle C}')
soundsc(swn,fs)