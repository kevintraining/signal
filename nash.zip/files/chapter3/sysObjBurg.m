%% Compute power spectrum using modified Periodogram.
%
fs = 8000; % Sampling rate
framesize = 60; % Data length (change this value to change 
                  % frequency resolution)
NFFT = 1024; % FFT length

% Create the System object for generating two sine functions.
hSin = dsp.SineWave('Frequency',[200,250],...
                    'Amplitude',[1,0.8],...
                    'SampleRate', fs);
hSin.SamplesPerFrame = framesize;

% Create the System object for the (modified) Periodogram.
hBurg = dsp.BurgSpectrumEstimator(...
    'EstimationOrder',6,...
    'SampleRate', hSin.SampleRate,...
    'FFTLengthSource','Property',...
    'FFTLength',NFFT);

% Compute frequency vector for the PSD plot
f = (0:floor(NFFT/2)+1)*(fs/NFFT);

% Generate a noisy sum of sines and compute its power spectrum.
x = sum(step(hSin),2) + 1.0e-06*randn(framesize,1); % Generate noisy sum of sine waves
Pxx = step(hBurg, x); % Compute power spectrum

% Display result
plot(f,10*log10(Pxx(1:length(f))));
grid on;
title('PSD of sum of sine waves using Burg method');
xlabel('Frequency(Hz)');
ylabel('PSD (dBW/Hz)');

%% Use Burg method to estimate spectrum of an AR process
release(hBurg); % release object so you can change the signal length

% Generate a sample from an AR process
x = randn(1000,1);
y = filter(1,[1 1/2 1/3 1/4 1/5],x); % Fourth order AR filter

% Compute Burg estimate of the AR spectrum
Pyy = step(hBurg,y);

% Display result
figure;
plot(f, 10*log10(Pyy(1:length(f))));
grid on;
title('Burg Spectral Density Estimate of AR process');
xlabel('Frequency (Hz)'); ylabel('PSD (dBW/Hz)');

% Compare with true AR spectrum
figure;
freqz(1,[1 1/2 1/3 1/4 1/5]); % Plot the true AR spectrum to compare with
                              % Burg estimate
title('True AR spectrum');