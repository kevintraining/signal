load ampWindow
% Contents of ampWindow.mat:
% - HA (dsp.LMSFilter) - same as before, provided for backup
% - x_window, d_window (dsp.SignalSource) - input signals with frame size
% 500, varying power level vs. time
% - ampWindow (double) - windowing function used to transform constant power
% signals x and d to the new signals x_window and d_window
% - Fs (double) - 8192 Hz
% - FrameSize (double) - 500 samples per frame

% Calculate the number of frames in the input signals to allocate space for
% the frequency response matrix
NumFrames = floor(length(d_window.Signal)/FrameSize);

%% Try runing the LMS algorithm with a varying-amplitude input signal

% Release all input signal System Objects and Adaptive Filter System Object
% to ensure signals start at beginning and non-tunable properties of LMS
% filter can be changed
releaseAll(x_window,d_window,HA)

% Change dsp.LMSFilter algorithm to 'LMS' if not already 'LMS'
HA.Method = 'LMS';

% Allocate space for frequency response of estimated filter vs. time
response = zeros(512,NumFrames);

i = 1;% counter for buffering frequency response

while ~isDone(x_window)
    [y,e,w] = step(HA,step(x_window),step(d_window),1,false);
    % Calculate the frequency response of the FIR filter for each frame
    % and populate the frequency response buffer
    [response(:,i),f] = freqz(w,1,[],Fs);
    i = i+1; % Increment counter
end

% Calculate time vector for start of each signal frame
t_frame = (0:FrameSize:length(d_window.Signal)-1)/Fs;

% Visualize estimated FIR filter response vs. time using a surface plot
fig = figure;subplot(1,2,1)
surf(t_frame,f,20*log10(abs(response)),'Linestyle','none')
xlabel('Time (s)')
ylabel('Frequency (Hz)')
zlabel('Power (dB)')% Filter is unstable due to input power variation
title({'Magnitude Response Estimate'; 'vs. Time for LMS Algorithm'});

%% Switch to the Normalized LMS algorithm and try again

% release all input signal System Objects and Adaptive Filter System Object
% to ensure signals start at beginning and non-tunable properties of LMS
% filter can be changed
releaseAll(x_window,d_window,HA)

% Change dsp.LMSFilter algorithm to 'Normalized LMS'
HA.Method = 'Normalized LMS';

% Allocate space for frequency response of estimated filter vs. time
response = zeros(512,length(t_frame));

i = 1;% counter for buffering frequency response

while ~isDone(x_window)
    [y,e,w] = step(HA,step(x_window),step(d_window),0.3,false);
    % Normalized LMS Filter still has step size parameter, but this time
    % it is for relative convergence speed control
    
    % Calculate the frequency response of the FIR filter for each frame
    % and populate the frequency response buffer
    [response(:,i),f] = freqz(w,1,[],Fs);
    i = i+1; % Increment counter
end

% Visualize estimated FIR filter response vs. time using a surface plot
figure(fig);subplot(1,2,2)
surf(t_frame,f,20*log10(abs(response)),'Linestyle','none')
xlabel('Time (s)')
ylabel('Frequency (Hz)')
zlabel('Power (dB)')
title({'Magnitude Response Estimate'; 'vs. Time for NLMS Algorithm'});