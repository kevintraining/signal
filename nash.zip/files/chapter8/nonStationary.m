load nonStationary

%% Convert x and d to dsp.SignalSource with SamplesPerFrame = 500 
% (if not already converted)
FrameSize = 500;

if isnumeric(x)
    x = dsp.SignalSource('Signal',x,'SamplesPerFrame',FrameSize);
end
if isnumeric(d)
    d = dsp.SignalSource('Signal',d,'SamplesPerFrame',FrameSize);
end

%% Play non-stationary signal, create variables for frame time and 
% allocate space for a magnitude response buffer to visualize filter
% evolution
soundsc(d_nonStat.Signal,Fs)

t_frame = (0:FrameSize:length(x.Signal)-1)/Fs;
response = zeros(512,length(t_frame));

%% Run adaptive filter frame by frame on stationary signal

% (need to release HA since we are changing the size of the input)
releaseAll(HA,x,d,d_nonStat)

i = 1;% counter for buffering frequency response
while ~isDone(x)% Keep iterating until there are no values of x.Signal remaining
    [y,e,w] = step(HA,step(x),step(d),1,false);% do not reset adaptive filter after each frame!
    % (When reset flag is set to true, the FIR coefficients reset to zero 
    % after each frame of inputs.  We want to continuously train the filter
    % weights to converge toward the correct frequency response.)
    
    % Calculate the frequency response of each frame's FIR filter weights,
    % and populate the frequency response buffer
    [response(:,i),f] = freqz(w,1,[],Fs);
    
    % Increment counter
    i = i+1;
end

% Visualize filter response vs. time using a surface plot
figure
subplot(1,2,1)
surf(t_frame,f,20*log10(abs(response)),'Linestyle','none')
view(-70,18)
zlim([-80 2])
title({'Evolution of FIR Filter Magnitude'; 'Response (for a Stationary Signal)'})
xlabel('Time (s)')
ylabel('Frequency (Hz)')
zlabel('Power (dB)')

%% Run adaptive filter frame by frame on non-stationary signal

releaseAll(HA,x,d,d_nonStat)
% (need to release HA since we are changing the size of the input)

i = 1;% counter for buffering frequency response
while ~isDone(x)% Keep iterating until there are no values of x.Signal remaining
    [y,e,w] = step(HA,step(x),step(d_nonStat),1,false);% do not reset adaptive filter after each frame!
    
    % Calculate the frequency response of FIR filter for each frame,
    % and populate the frequency response buffer
    [response(:,i),f] = freqz(w,1,[],Fs);
    
    % Increment counter
    i = i+1;
end

% Visualize filter response vs. time using a surface plot
subplot(1,2,2)
surf(t_frame,f,20*log10(abs(response)),'Linestyle','none')
view(-70,18)
zlim([-80 2])
title({'Evolution of FIR Filter Magnitude'; 'Response (for a Non-Stationary Signal)'})
xlabel('Time (s)')
ylabel('Frequency (Hz)')
zlabel('Power (dB)')