function windemo(width)

% WINDEMO Low-level demonstration of the windowing method for 
% FIR filter design.
%
% The input WIDTH gives the width of a rectangular window.

% Ideal lowpass filter specifications.

% Passband edge frequency (kHz):
FE = 1.5;
% Transition width (kHz):
W = 0.5;
% Center edge frequency in transition band: 
FC = FE + W/2; 
% Sampling frequency (kHz):
FS = 8;

% 1. Sample the ideal frequency response at the sampling frequency.

% Sample length must be large enough to prevent  
% time-domain aliasing with the IFFT: 
N = 512; 
% Number of 1s until cutoff:
c = N*FC/FS + 1;
% Sampled frequency response:
H = zeros(1,N);
H(1:c) = ones(1,c);
% Impose conjugate symmetry to make 
% IFFT (filter coefficients) pure real:
H((N-c+2):N) = ones(1,c-1);
% Plot the sampled ideal frequency response 
% in the range [0 pi]:
subplot(2,2,1)
F = linspace(0,2*pi,N);
stairs(F,H)
axis([0 pi -0.2 1.2])
title('Ideal Frequency Response')
xlabel('Frequency')
ylabel('Magnitude')

% 2. Compute the IFFT (ideal filter coefficients).

h = ifft(H);
% Shift zero-frequency to center for windowing:
h = fftshift(h);
% Plot the ideal impulse response:
subplot(2,2,2)
t = -N/2:N/2-1;
stem(t,h,'m')
axis([-100 100 -.1 .1]) 
title('Ideal Impulse Response')
xlabel('Time')
ylabel('Magnitude')

% 3. Window the ideal impulse response.

% Rectangular window:
w = [zeros(1,(N-width)/2) ones(1,width) zeros(1,(N-width)/2)];
% Windowed impulse response:
hw = h.*w; 
% Plot the windowed impulse response:
subplot(2,2,4)
stem(t,hw,'m') 
hold on
% Plot window:
stairs(t,w,'r','LineWidth',2) 
axis([-100 100 -.1 .1]) 
title('Windowed Impulse Response')
xlabel('Time')
ylabel('Magnitude')
hold off

% 4. Compute the FFT (frequency response of the FIR filter).

HW = fft(hw);
% Plot the frequency response 
% in the range [0 pi]:
subplot(2,2,3)
plot(F,abs(HW))
axis([0 pi -0.2 1.2])
title('FIR Frequency Response')
xlabel('Frequency')
ylabel('Magnitude')