%% Design arbitrary response IIR filter
%  ====================================
% Set filter magnitude specification
fs = 8000;
fNyq = fs/2;
f = [0, 150, 150, 1800, 1800, 2200, 2200, fNyq]/fNyq;
m = [1, 1, 0, 0, 1, 1, 0, 0];
% Design filter and plot magnitude resonse
[b,a] = yulewalk(20,f,m);
[h,w] = freqz(b,a,128);
plot(f,m,'r--',w/pi,abs(h),'b-','LineWidth',2);
legend('Magnitude specification','Filter response');

%% Load the communication signal and plot the spectrum
load noisyX
figure;
pwelch(noisyX,[],[],[],fs);
title('PSD of the communication signal');
% soundsc(noisyX);

%% Filter the noisy signal and look at the spectrum
y = filter(b,a,noisyX);
figure;
pwelch(y,[],[],[],fs);
title('PSD of the message signal');

%% Plot the communication signal and the message signal (after filtering)
figure;
plot(noisyX);
hold on;
plot(y,'r','LineWidth',2);
xlim([0 200]); % Zoom into the first 200 samples
legend('Communication signal','Message signal');
% soundsc(y);