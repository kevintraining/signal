%% Skip the load function if you have the filters
load solnFilters % In case you dont have the filters in your workspace

%% Create the signal to be decimated
fs = 100000;
n = (0:50999)';
t = n/fs;
x = sin(2*pi*100*t);

%% Perform decimation
% Use single rate filter followed by downsampler
tic
y_filt = filter(Hlp150,x);
y_simple = downsample(y_filt,150);
toc
%% Use polyphase downsampling filter
tic
y_poly = step(Hlp150_poly,x);
toc
%% Use multistage downsampling filter
tic
tmp = step(Hlp150_multi.Stage1,x);
tmp = step(Hlp150_multi.Stage2,tmp);
y_multi = step(Hlp150_multi.Stage3,tmp);
toc

%% Plot the downsampled signals
plot(y_simple); hold all;
plot(y_poly);
plot(y_multi); hold off;
legend('y\_simple','y\_poly','y\_multi');
% The polyphase implementation should be identical to the single-rate
figure;
plot(y_simple-y_poly);
legend('(y\_simple - y\_poly)');

%% Look at the PSD of all the signals
figure; pwelch(x,[],[],[],fs); title('PSD of signal x');
figure; pwelch(y_poly,[],[],[],fs/150); title('PSD of y\_poly');
figure; pwelch(y_multi,[],[],[],fs/150); title('PSD of y\_multi');
