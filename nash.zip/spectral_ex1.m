%% Objective
%
% * In this exercse, you need to calculate and plot the magnitude spectra of two
%   complex tones.
%
% * Plot the 2 spectra in one figure.

%% Clear all variables.
clear

%% Create discrete-time signal x1[n] = complex tone at 10 Hz. Fs = 100 Hz.
Fs = 100;
t  = (0:3) / Fs;
x1  = exp(1i * 2 * pi * 10 * t);

%% Create discrete-time signal x2[n] = complex tone at -10 Hz. Fs = 100 Hz.
% TODO: Add your code here.
x2 = exp(1i * 2 * pi * -10 * t);

%% Calculate FFT of x1[n].
% TODO: Add your code here.
X1 = fftshift(fft(x1, 2^17));
f1 = fftf(length(X1), Fs);

%% Calculate FFT of x2[n].
% TODO: Add your code here.
X2 = fftshift(fft(x2, 2^17));
f2 = fftf(length(X2), Fs);

%% Plot FFT of x1[n].
% TODO: Add your code here.
figure(1)
plot(f1, abs(X1))
xlabel('Frequency (Hz)')

%% Plot FFT of x2[n].
% TODO: Add your code here.
hold on
plot(f2, abs(X2))