%% Objective
%
% * In this exercse, you need to calculate and plot the magnitude spectra of two
%   complex tones.
%
% * Plot the 2 spectra in one figure.

%% Clear all variables.
clear

%% Create discrete-time signal x1[n] = complex tone at 10 Hz. Fs = 100 Hz.
Fs = 100;
t  = (0:3) / Fs;
x1  = exp(1i * 2 * pi * 10 * t);

%% Create discrete-time signal x2[n] = complex tone at -10 Hz. Fs = 100 Hz.
% TODO: Add your code here.

%% Calculate FFT of x1[n].
% TODO: Add your code here.

%% Calculate FFT of x2[n].
% TODO: Add your code here.

%% Plot FFT of x1[n].
% TODO: Add your code here.

%% Plot FFT of x2[n].
% TODO: Add your code here.
