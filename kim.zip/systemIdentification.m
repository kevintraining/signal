%% Start from scratch.
clear
rng(123, 'twister')

%% Load unknown filter from MATLAB MAT file.
load unknownFilter

%% Analyze the response of the unknown system for reference.
fvtool(H_unknown, 'Fs', Fs)

%% Generate white noise for the adaptive filter input signal.
x = 0.05*randn(5e4,1);
t = (0:length(x)-1)/Fs;
soundsc(x,Fs)

%% Generate the desired signal by applying the unknown system to the input.
d = step(H_unknown,x);
soundsc(d,Fs)

%% Create an LMS filter and apply it to x and d to get the estimated filter
%% weights w. Note that the default step size is 0.1.
HA = dsp.LMSFilter
[y,e,w] = step(HA,x,d);

%% Visualize convergence behavior and estimate filter response.
fig = figure;
plot(t,e,'ro')
xlim([0 max(t)])
hold all
fvtool(w, 1, H_unknown, 'Fs', Fs)


%% Release HA to reset the FIR filter weights to zero. Change the StepSize
%% property, run the adaptive filter again, and visualize the performance.
release(HA)
HA.StepSize = 0.5;
[y,e,w] = step(HA,x,d);
figure(fig)
plot(t,e,'bx')
fvtool(w,1,H_unknown)

release(HA)
HA.WeightsResetInputPort = true;
HA.StepSize = 1;
[y,e,w] = step(HA,x,d,true);
figure(fig)
plot(t,e,'kx')
fvtool(w,1,H_unknown)

HA.StepSize = 25;
[y,e,w] = step(HA,x,d,true);
figure(fig)
plot(t,e)
hold off
fvtool(w,1,H_unknown)


%% Step-size.
muMax = maxstep(HA,x)

HA.StepSizeSource
release(HA)
HA.StepSizeSource = 'Input Port';

[y,e,w] = step(HA,x,d,0.01,true);
figure
plot(t,e)
xlim([0 max(t)])
hold all

[y,e,w] = step(HA,x,d,0.1,true);
plot(t,e)

[y,e,w] = step(HA,x,d,1,true);
plot(t,e)
hold off


