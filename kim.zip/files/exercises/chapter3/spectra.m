%% 1
% Bring the data into MATLAB
% Alternatively, you can use the import wizard: run "uiimport('mySig.xls')"

[data, textLabel] = xlsread('mySig.xls');
t = data(:,1);
y = data(:,2);

%% 2
% Given the time information, the sampling frequency can be found by taking
% the reciprocal of the average of the difference between the adjacent time
% values.
Fs = 1/mean(diff(t)) %#ok<*NOPTS>

%% 3
% Compute two-sided periodogram. The default window is rectangular.
[Pyy,w] = periodogram(y,[],[],Fs,'twosided');
figure;
plot(w,10*log10(Pyy)); grid on;
title('Periodogram with a rectangular window');
xlabel('Frequency (Hz)');
ylabel('PSD (dB/Hz)');
axis([0 1000 -100 10]);

%% 4
% Compute periodograms with different windows. Notice that windowing 
% lowers the side lobes, but possibly increases the size of the mainlobe.
tri = triang(length(y));
[Pyy_tri,w] = periodogram(y,tri,[],Fs,'twosided');
ham = hamming(length(y));
[Pyy_ham,w] = periodogram(y,ham,[],Fs,'twosided');
cheb = chebwin(length(y));
[Pyy_cheb,w] = periodogram(y,cheb,[],Fs,'twosided');
figure;
subplot(3,1,1), plot(w,10*log10(Pyy_tri)); grid on; axis([0 500 -200 10]);
title('Periodogram PSD Estimates with different windows');
xlabel('Triangular window'); ylabel('PSD(dB/Hz)');
subplot(3,1,2), plot(w,10*log10(Pyy_ham)); grid on; axis([0 500 -200 10]);
xlabel('Hamming window'); ylabel('PSD(dB/Hz)');
subplot(3,1,3), plot(w,10*log10(Pyy_cheb)); grid on; axis([0 500 -200 10]);
xlabel('Chebyshev window'); ylabel('PSD(dB/Hz)');

%% 5
% As the segment length decreases, the number of segments increases, so
% the variance of the PSD decreases. However, the lower segment length
% leads to an increase in the size of main lobe, which in turns
% decreases the spectral resolution.
[Pyy_w64,w] = pwelch(y,64,[],2048,Fs);
[Pyy_w256,w] = pwelch(y,256,[],2048,Fs);
[Pyy_w1024,w] = pwelch(y,1024,[],2048,Fs);
figure
subplot(3,1,1), plot(w,10*log10(Pyy_w64)); grid on; axis([0 500 -100 10]);
title('PSD Estimates Using Welch Method');
xlabel('Segment length = 64');
ylabel('PSD(dB/Hz)');
subplot(3,1,2), plot(w,10*log10(Pyy_w256)); grid on; axis([0 500 -100 10]);
xlabel('Segment length = 256');
ylabel('PSD(dB/Hz)');
subplot(3,1,3), plot(w,10*log10(Pyy_w1024)); grid on; axis([0 500 -100 10]);
xlabel('Segment length = 1024');
ylabel('PSD(dB/Hz)');