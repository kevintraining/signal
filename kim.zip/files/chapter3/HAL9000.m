%% HAL9000 Demonstrates time-varying spectra at progressively reduced sample rates.

load HAL9000
%%
spectrogram(x,kaiser(100,5),75,512,fs,'yaxis')
title('Original Signal')
colorbar
sound(x,fs)
pause(5)
%%
x4 = downsample(x,4);
figure
spectrogram(x4,kaiser(100,5),75,512,fs/4,'yaxis')
title('Downsampled by a Factor of 4')
colorbar
sound(x4,fs/4)
pause(5)
%%
x8 = downsample(x,8);
figure
spectrogram(x8,kaiser(100,5),75,512,fs/8,'yaxis')
title('Downsampled by a Factor of 8')
colorbar
sound(x8,fs/8)
pause(5)
%%
x16 = downsample(x,16);
figure
spectrogram(x16,kaiser(100,5),75,512,fs/16,'yaxis')
title('Downsampled by a Factor of 16')
colorbar
sound(x16,fs/16)
pause(5)