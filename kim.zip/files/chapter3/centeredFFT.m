function [X,freq]=centeredFFT(x,Fs,N)
%
% [X,freq]=centeredFFT(x,Fs,N)
%
% This function that helps in plotting the two-sided spectrum
% of signal 'x' (zero padded if length(x) < N).
%
% Fs is the sampling rate
% N is the FFT length (number of points returned in the FFT result)
 
%this part of the code generates that frequency axis
if mod(N,2)==0
    k=-N/2:N/2-1; % N even
else
    k=-(N-1)/2:(N-1)/2; % N odd
end
 
dF=Fs/N;
freq=k*dF; %creates the frequency axis
X=fft(x,N)/N; % normalizes the data
X=fftshift(X);%shifts the fft data so that it is centered
% Plot the power spectrum
plot(freq,20*log10(abs(X))); grid on;
xlabel('Frequency (Hz) --->');
ylabel('FFT Magnitude (dB) --->');
end