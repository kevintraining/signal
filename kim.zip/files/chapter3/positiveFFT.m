function [X,freq]=positiveFFT(x,Fs,N)
%
% [X,freq]=positiveFFT(x,Fs,N)
%
% This function helps in plotting the one-sided spectrum
% of signal x (zero padded if length(x) < N)
%
% Fs is the sampling rate in Hz
% N is the number of points returned in the FFT result
 
k=0:N-1;     %create a vector from 0 to N-1
dF=Fs/N;      %get the frequency interval
freq=k*dF;    %create the frequency range
X=fft(x,N)/N; % normalize the data
 
%only want the first half of the FFT, since the other half is redundant
cutOff = floor(N/2)+1; 
 
%take only the first half of the spectrum
X = X(1:cutOff);
freq = freq(1:cutOff);
% Plot the power spectrum
plot(freq,20*log10(abs(X))); grid on;
xlabel('Frequency (Hz) --->');
ylabel('FFT Magnitude (dB) --->');
end