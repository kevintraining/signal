%%
% Design 8-th order IIR filter with frequency response
% defined by the frequency and gain arrays below.

f = [0 .15 .4 .5 1]; % frequency array
a = [1 1.6 1 1e-04 1e-04]; % required gains at above frequncies
edges = [0 .4 .5 1]; % frequency edges (always needs the end frequencies)
w1 = [1 1 1 10 10]; % weights at frequency points
% plot specified frequency response
plot(f,20*log10(a)); grid on;
title('Desired Frequency Response');
xlabel('Normalized Frequency');
ylabel('Magnitude Response (dB)');
%% Design 1: use iirlpnorm
Nb = 8; % Numerator order
Na = 8; % Denominator order
[num,den] = iirlpnorm(Nb,Na,f,edges,a,w1);
Hd1 = dfilt.df2(num,den);
% change weight vector to improve stop band response
w2 = [1 1 1 100 100];
[num,den] = iirlpnorm(Nb,Na,f,edges,a,w2);
Hd2 = dfilt.df2(num,den);
hfvt1 = fvtool(Hd1,Hd2,'DesignMask','on');
legend(hfvt1,'weight = [10 10]','weight = [100 100]');
%% Design 2: use fdesign.arbmag
% Single Band Design
d = fdesign.arbmag('Nb,Na,F,A',Nb,Na,f,a);
Hd3 = design(d,'iirlpnorm','Weights',w2);
% Multi-band Design
Nbands = 2;
f1 = f(1:3);
a1 = a(1:3);
f2 = f(4:end);
a2 = a(4:end);
w21 = w2(1:3);
w22 = w2(4:end);
d = fdesign.arbmag('Nb,Na,B,F,A',Nb,Na,Nbands,f1,a1,f2,a2);
Hd4 = design(d,'iirlpnorm','B1Weights',w21,'B2Weights',w22);
hfvt2 = fvtool(Hd3,Hd4);
legend(hfvt2,'Single Band','Multi-band');
measureHd3 = measure(Hd3)
measureHd4 = measure(Hd4)
%% Design a cheaper filter by lowering the denominator order
% One benefit of using iirlpnorm design is that it allows different
% numerator and denominator orders.
Nb = 8;
Na = 6;
d = fdesign.arbmag('Nb,Na,B,F,A',Nb,Na,Nbands,f1,a1,f2,a2);
Hd5 = design(d,'iirlpnorm','B1Weights',w21,'B2Weights',w22);
hfvt3 = fvtool(Hd4,Hd5);
legend(hfvt3,'Nb=8 Na=8','Nb=8 Na=6');
% Compare performance at specified points
measureHd5 = measure(Hd5)
% Compare relative implementation costs
costHd4 = cost(Hd4)
costHd5 = cost(Hd5)
%% Design a lowpass filter of order 8 with Fpass = 0.4
% Lowpass passband ripple has a mean of 0 dB
% and Fstop = 0.5
d = fdesign.lowpass('N,Fp,Fst',8,.4,.5);
% Specify sampling rate for the design (optional)
normalizefreq(d,false,1e04);
Hd6 = design(d,'iirlpnorm');
fvtool(Hd6);
%% Design a comparable elliptic filter
% Lowpass passband ripple has max at 0 dB
d = fdesign.lowpass('N,Fp,Ap,Ast',8,.4,0.0084,66.25);
% Specify sampling rate for the design (optional)
normalizefreq(d,false,1e04);
Hd7 = design(d, 'ellip');
hfvt4 = fvtool(Hd6,Hd7);
legend(hfvt4,'IIRLPNORM design','ELLIP design');
%%
% The response of the two filters is very similar. Zooming into the
% passband accentuates the point. However, the magnitude of the filter
% designed with IIRLPNORM is not constrained to be less than 0 dB.
axis([0 2.1 -.01 .01])
%% Measure the responses for the filters that we designed
measureHd6 = measure(Hd6)
measureHd7 = measure(Hd7)
%% Reduce the denominator order to reduce cost
d = fdesign.lowpass('Nb,Na,Fp,Fst',8,8,0.4,0.45);
Hd8 = design(d,'iirlpnorm');
fvtool(Hd8);
measureHd8 = measure(Hd8)
%%
d = fdesign.lowpass('Nb,Na,Fp,Fst',8,6,0.4,0.45);
Hd9 = design(d,'iirlpnorm');
hfvt5 = fvtool(Hd8,Hd9);
legend(hfvt5,'Nb=8 Na=8','Nb=8 Na=6');
measureHd9 = measure(Hd9)
costHd8 = cost(Hd8)
costHd9 = cost(Hd9)
%%
d = fdesign.lowpass('Nb,Na,Fp,Fst',10,8,0.4,0.45);
Hd10 = design(d,'iirlpnorm');
fvtool(Hd10);
measureHd10 = measure(Hd10)
costHd10 = cost(Hd10)
