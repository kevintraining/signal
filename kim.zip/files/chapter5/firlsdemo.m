%% FIRLSDEMO Designs a 24th-order anti-symmetric filter with piecewise
%  linear passbands using FIRLS and plots the desired and actual
%  frequency responses. 

% Give frequency-amplitude characteristics.
F = [0 0.3 0.4 0.6 0.7 0.9]; 
A = [0 1 0 0 0.5 0.5];

% Specify odd symmetry (type III and type IV) to force zero response
% at F = 1.
ftype = 'hilbert';

% Compute filter approximation.
b = firls(24,F,A,ftype);
b2 = firpm(24,F,A,ftype);

%% Plot results.
[H,f] = freqz(b,1,512,2);
[H2,f2] = freqz(b2,1,512,2);
plot(F,A,f,abs(H),f,abs(H2)), grid on
legend('desired','firls','firpm');
title('FIRLS/FIRPM Design')
% Note that 'firls' minimizes total error energy whereas 'firpm' minimizes
% the maximum error.
hold off
