%% Design a multirate filter using a filter specification object
%
% Specify decimation factor.
M = 4;

% Create a filter specification object indicating the decimation factor,
% filter response type, and filter specifications.
lpDecSpec = fdesign.decimator(M,'lowpass','Fp,Fst,Ap,Ast',0.2,0.25,0.1,60);

% You could also indicate only the response type, and let MATLAB choose the
% specifications for you. Comment out the statement above and uncomment the
% statement below to use default specifications for the lowpass filter.

% lpDecSpec = fdesign.decimator(M,'lowpass');

% Find out what designmethods are available for your specifications.
designmethods(lpDecSpec)

%% Choose a design method and design the decimator.
lpDecFIR = design(lpDecSpec,'equiripple','SystemObject',true);
fvtool(lpDecFIR); % Check filter performance.
% Check "Analysis -> Filter Information" in FVTool to see how much
% computation you saved by using a multirate filter.
% See if all numbers make sense.

%% Uncomment the following to design the same filter without decimation
%  Compare the cost with the decimating filter
%
% lpSpec = fdesign.lowpass('Fp,Fst,Ap,Ast',0.2,0.25,0.1,60);
% HlpFIR = design(lpSpec,'kaiserwin');
% fvtool(HlpFIR);

%% Create a noisy tone signal to test the decimator
fs = 8000; % sampling rate
f = 500;   % frequency of the tone
% Make sure that the number of samples is equal to the integer multiple of the
% decimation factor.
t = (0:1/fs:(1-1/fs))';
x = sin(2*pi*f*t) + 0.2*randn(length(t),1);
pwelch(x); % Look at the spectrum of the signal.
title('PSD of the signal before decimation');
% Play the audio.
soundsc(x,fs);

%% Decimate the signal using the lowpass antialiasing filter lpDecFIR.
xLpDown = step(lpDecFIR,x);
figure;
pwelch(xLpDown);
title('PSD of the signal after decimation');
% Play the decimated audio
soundsc(xLpDown,fs/M);

%% *****************************************************
%  Design a bandpass decimator to extract the tone while 
%  performing decimation.
%  *****************************************************
bpDecSpec = fdesign.decimator(M,'bandpass',...
    'fst1,fp1,fp2,fst2,ast1,ap,ast2',...
    400,450,550,600,50,.05,50,fs);
bpDecFIR = design(bpDecSpec,'equiripple','SystemObject',true);
fvtool(bpDecFIR);
% Check filter information in FVTool to see how much computation you saved
% by using a multirate filter. See if all numbers make sense.

%% Apply the decimating bandpass filter.
xBpDown = step(bpDecFIR,x);
figure;
pwelch(xBpDown);
title('PSD of the signal after decimation with a bandpass filter');
% Play the audio
soundsc(xBpDown,fs/4);