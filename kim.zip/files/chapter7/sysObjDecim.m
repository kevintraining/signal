%% Design a multirate decimator using dsp.FIRDecimator System object
%
% Specify decimation factor.
M = 5;
lpSpec = fdesign.lowpass('Fp,Fst,Ap,Ast',0.95/M,1/M,0.1,60);
lpFIR = design(lpSpec,'equiripple');
lpDecSysObj = dsp.FIRDecimator(M,lpFIR.Numerator);
% Check frequency response of the decimating filter
freqz(lpDecSysObj);
% Get the implementation cost
cost(lpDecSysObj)
%% Test the decimator on a signal
%
% Create a dsp.AudioFileReader System object that reads audio from a file.
auReader = dsp.AudioFileReader('OutputDataType','single',...
    'SamplesPerFrame',1000*M,...
    'Filename','airport.wav');
% Create an audio player System object to play the resulting audio.
auPlayer = dsp.AudioPlayer(auReader.SampleRate/M);

% Process the audio signal through the decimator and play it.
while ~isDone(auReader)
     frame = step(auReader); % Read signal from file
     y = step(lpDecSysObj, frame); % Decimate signal
     step(auPlayer, y); % Play audio
end
% Release System objects
release(auReader);
release(lpDecSysObj);
pause(0.5); % Pause to allow auPlayer to finish playing audio
release(auPlayer);