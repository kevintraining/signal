% TRANSFERPLOT Plots a transfer function in the z-plane and shows the
% frequency response around the unit circle.

% Plotting range (polar coordinates):
omega = linspace(0,2*pi);
r = linspace(0,2);
[OM,R] = meshgrid(omega,r);

% Transfer function:
z = R.*exp(1i*OM);
H = 8*(z-1)./(z.^2-1.2*z+0.72);
M = abs(H);

% Display zeros, poles, gain in Command Window:
fprintf('Zeros: %f\nPoles: %f, %f\nGain: %f\n',...
    roots([1 -1]),roots([1 -1.2 0.72]),8) 

% Transform polar coordinates to Cartesian:
[X,Y] = pol2cart(OM,R); 

% Plot transfer function:
surf(X,Y,M);
shading interp
set(gca, 'CLim', [0 50])
axis([-2 2 -2 2 0 50])
axis square
xlabel('Real Axis')
ylabel('Imaginary Axis')
hold on

% Plot unit circle (black) and frequency response (red):
plot3(cos(omega), sin(omega), zeros(size(omega)), 'k', 'LineWidth', 3)

z = exp(1i*omega);
FREQZ = 8*(z-1)./(z.^2-1.2*z+0.72);
F = abs(FREQZ);
plot3(cos(omega), sin(omega), F, 'r', 'LineWidth', 3)

% Unwrap the frequency response and plot:
figure
plot(omega, F, 'r', 'LineWidth', 3)
grid on
xlabel('Frequency')
ylabel('Response')