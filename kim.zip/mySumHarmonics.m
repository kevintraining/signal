
function [y,t] = mySumHarmonics(f0, nHarmonics)

oddNums = 1:2:(2*nHarmonics - 1);
A = 1./ oddNums;        % Row vector of amplitudes
f = (f0 * oddNums).';   % Column vector of sine frequencies
fs = 3 * max(f);

t = 0 : 1/fs : 3/f0 ;

x = zeros(size(t));
for k = 1:length(A)
    x = x + A(k)*sin(2*pi*f(k)*t);
end

plot (t,x)

end

