%% Generate sum of two sinusoids
%
% * x[n] = A(1)*sin(2*pi*f(1)*t) + A(2)*sin(2*pi*f(2)*t);
%
A  = [1, 1/3];  % Amplitudes
f  = [10; 30];  % Frequencies
fs = 100;       % Sampling rate
t  = (0 : 4) / fs;
x  = A*sin(2*pi*f*t);

