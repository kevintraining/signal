%% Clean up.
clear

%% Create a complex tone x[n].
Fs = 100;
t  = (0:100) / Fs;
x  = exp(1i * 2 * pi * 10 * t);

%% Calculate FFT.
X = fftshift(fft(x, 2^17));
f = fftf(length(X), Fs);

%% Plot FFT.
figure(1)
clf
plot(f, abs(X))
xlabel('Frequency (Hz)')
ylabel('|X(f)|')
title('Magnitude Spectrum')

%% Apply Windowing.
% TODO.

%% Calculate FFT.
X1 = fftshift(fft(x1, 2^17));
f1 = fftf(length(X1), Fs);
hold on
plot(f1, abs(X1))

