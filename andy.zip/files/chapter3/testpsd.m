%% Computation of PSD through Periodogram and DFT of autocorrelation
Fs = 100; % Sampling rate
t = 0:1/Fs:10-1/Fs; % Array of time indices for 10 seconds
% Set DFT length (make sure this is more then twice the signal length to
% capture the entire autocorrelation sequence)
ndft = 3000;
% Create a signal that is a sum of two sinusoids.
% Remember that the power of a sinusoid of amplitude "A" is (A^2)/2.
% Experiment with different amplitudes to test.
a1 = 2.0;
a2 = 1.0;
y = a1*sin(2*pi*15*t) + a2*sin(2*pi*30*t);
%% Compute Periodogram
Y = fft(y,ndft);
% Generate the frequency vector at which DFT is computed
f = Fs*(0:ndft-1)/ndft;
% Compute energy spectral density (for the finite length signal)
ESD = Y.*conj(Y)/ndft;
figure(1); plot(f,ESD)
title('Periodogram');
%% Autocorrelation
ryy = xcorr(y);
% Compute DFT of autocorrelation (normalised by DFT length)
Ryy = fft(ryy,ndft)/ndft;
figure(2); plot(f,abs(Ryy))
title('DFT of Autocorrelation')
%% Check if signal powers are correctly computed
% Compute powers of the two sinusoids that we added (power of a sinusoid
% with amplitude A is A^2/2)
format compact;
signal_pwr_15Hz = a1^2/2
signal_pwr_30Hz = a2^2/2
signal_tot_pwr = signal_pwr_15Hz + signal_pwr_30Hz
%% First check total power from both the methods
totpwrPeriodogram = sum(ESD)/length(y)
totpwrAutocorr = sum(abs(Ryy))/length(y)
%% Measure signal power for each sinusoid
% Remember that the power of each sinusoid is split into two parts,
% one at +f and another at -f. So, expect to see half the power for each
% peak. Therefore we multiply the sum around one peak by 2. Also we compute
% power from energy by dividing by length of signal.
%
% First, for the 15 Hz sinusoid --
indx15Hz = find(f > 10 & f < 20);
measured_pwr15Hz = 2 * sum(ESD(indx15Hz))/length(y)
%% Now for the 30 Hz sinusoid --
indx30Hz = find(f > 25 & f < 35);
measured_pwr30Hz = 2 * sum(ESD(indx30Hz))/length(y)
