%% WHALEFFT Spectral analysis of a blue whale B call.
%
%
%% Read in the data.
[y,fs] = audioread('bluewhale.au');

%% Optional
% Plot the whale call signal and listen to it.
% plot(y); grid on;
% soundsc(y,fs);

%% Index into the signal to extract the first B call.
BCall = y(2.45e4:3.10e4);
tB = 0:1/fs:(length(BCall)-1)/fs; % Time base.

%% Compute the DFT and the power.
n = length(BCall); % Window length
Y = fft(BCall); % DFT of signal
f = (0:n-1)*(fs/n); % Frequency range
P = Y.*conj(Y)/n; % Power of the DFT

%% Plot the first half of the periodogram.
figure; plot(f(1:floor(n/2)),P(1:floor(n/2)))
xlabel('Frequency (Hz) --->');
title('{\bf Component Frequencies of a Blue Whale B Call}')