%% Compare "periodogram" vs. "pwelch" for clean signal
% Run the program as it is, what do you observe?
% Increase the signal duration, T, to get longer signal, does it
% change anything?
%
Fs = 1000;
T = 2; % signal duration in seconds
t = 0:1/Fs:max(0.6,T); % put a lower limit of 0.6 sec on duration
% Create clean signal, a sum of two sinusoids
x = cos(2*pi*t*200)+cos(2*pi*t*203);
nfft = 512;
% Compute and plot periodogram
figure(1); periodogram(x,[],nfft,Fs,'onesided');
% Compute and plot Welch estimate
figure(2); pwelch(x,[],128,nfft,Fs);
