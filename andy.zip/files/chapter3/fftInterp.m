%% FFTINTERP Demonstrates the use of the FFT for vector data interpolation.
%
% In 1866, a paper by the German mathematician Carl Freidrich Gauss titled
% "Theoria interpolationis methodo nova tractata" was published posthumously.
% It has been dated to 1805. It contains the first indisputable use of the
% FFT, which is widely attributed to Cooley and Tukey in 1965. 
%
% Gauss was interested in the problem of computing accurate asteroid orbits
% from observations of their positions. His paper contains the following data
% on the asteroid Pallas:
%
% Ascension     Declination
% (degrees)      (minutes)
% ---------     -----------
%     0             408
%    30              89
%    60             -66
%    90              10
%   120             338
%   150             807
%   180            1238 
%   210            1511
%   240            1583
%   270            1462
%   300            1183
%   330             804
%
% Gauss interpolates a trigonometric polynomial with 12 coefficients to the 
% 12 data points. Gauss could have solved the resulting 12 x 12 system of 
% linear equations by hand, but he did not. Instead, because he was Gauss 
% (and intrigued by the symmetries of sine and cosine), he looked for a 
% shortcut. He discovered a way to separate the equations into three subproblems 
% that were solved much more easily. The solutions to the subproblems were 
% then recombined to form the desired solution. Gauss' method of splitting 
% and recombining is now at the heart of all modern FFT algorithms.
%
% References:
% 1. H. H. Goldstine, "A History of Numerical Analysis from the 16th through
%    the 19th Century," Springer-Verlag, Berlin, 1977.
% 2. M. Heideman, D. Johnson, and C. Burrus, "Gauss and the history of the 
%    fast Fourier transform," Arch. Hist. Exact Sciences, 34 (1985), pp. 265-277

%% Data.
Asc = 0:30:330; 
Dec = [408 89 -66 10 338 807 1238 1511 1583 1462 1183 804];

%% Use the FFT to interpolate a trigonometric polynomial of the form
%  a0 + a1*cos(2*pi*x/360) + b1*sin(2*pi*x/360) ...
%     + a2*cos(2*pi*2*x/360) + b2*sin(2*pi*2*x/360) ...
%     ...
%     + a5*cos(2*pi*5*x/360) + b5*sin(2*pi*5*x/360) ...
%     + a6*cos(2*pi*6*x/360)
N = length(Dec);
M = floor((N+1)/2);
DDec = fft(Dec);
a0 = DDec(1)/N; 
an = 2*real(DDec(2:M))/N;
a6 = DDec(M+1)/N;
bn = -2*imag(DDec(2:M))/N;

%% Plot the data and the interpolant.
plot(Asc,Dec,'ro','Linewidth',2)
hold on
x = 0:0.01:360;
n = 1:length(an);
y = a0 + an*cos(2*pi*n'*x/360) + bn*sin(2*pi*n'*x/360) + a6*cos(2*pi*6*x/360); 
plot(x,y,'Linewidth',2)
xlim([0 360])
grid on
xlabel('Ascension (Degrees)')
ylabel('Declination (Minutes)')
title('{\bf Position of the Asteroid Pallas}')
legend('Data','FFT Interpolant','Location','NW')