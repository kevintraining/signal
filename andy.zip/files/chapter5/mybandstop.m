clc%% Start design by specifying sampling rate, Fs
Fs = 22050;
%% Check available filter response types
doc fdesign.responses
%% "bandstop" seems to be a valid response type
d = fdesign.bandstop;
set(d,'specification') % Look at the command window for the specification set
%% The default specification (first one in the list) is the one we want
% Note that appending the sampling rate at the end, turns off the
% normalized frequency mode. Also note that we use 'fdesign.bandstop' again
% to specify the parameters. We could have omitted the specification string
% for the default specification.
d = fdesign.bandstop('Fp1,Fst1,Fst2,Fp2,Ap1,Ast,Ap2',...
    800,1000,4000,4200,1,10,1,Fs);
%% Find out what design methods are available for this specification
methods = designmethods(d,'iir') %#ok<*NOPTS>
%% Since we only had passband ripple specified, try 'cheby1'
Hd = design(d,'cheby1')
fvt1 = fvtool(Hd);
% Zoom in around the area of interest
axis([0,5,-40,10]);
%% Check filter structure
info(Hd) % needs DSP System Toolbox
%% Measure filter performance
measure(Hd) % needs DSP System Toolbox
%% Find cost for implementation
cost(Hd) % needs DSP System Toolbox
%% Was that the best solution? Try all applicable IIR methods
Halliir = design(d,'alliir') % Note that they are all SOS structures
setfilter(fvt1, Halliir);
% Zoom in around the area of interest
axis([0,5,-40,10]);
legend(fvt1,methods{:});
%% Check for the smallest filter
filtercount = length(Halliir)
for n = 1:filtercount;
    stagecount(n) = size(Halliir(n).sosMatrix,1);
end
[minstages,indx] = min(stagecount)
shortest = methods(indx)
%% Measure filter performance
measure(Halliir(indx)) % needs DSP System Toolbox
%% Find cost for implementation
cost(Halliir(indx)) % needs DSP System Toolbox
%% Apply filter
[x,fs] = audioread('guitar.wav');
y = filter(Halliir(indx),x);
%% Play original sound
soundsc(x,fs);
%% Play filtered sound
soundsc(y,fs);
%% Compare spectra (before and after filtering)
figure; pwelch(x,[],[],[],fs);
figure; pwelch(y,[],[],[],fs);
