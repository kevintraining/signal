%% Clean up.
clear

%% Create discrete-time signal x[n].
Fs = 100;
t  = (0:3) / Fs;
x  = exp(1i * 2 * pi * 10 * t);

%% Calculate FFT.
X = fftshift(fft(x, 2^17));
f = fftf(length(X), Fs);

%% Plot FFT.
figure(1)
clf
plot(f, abs(X))
xlabel('Frequency (Hz)')
ylabel('|X(f)|')
title('Magnitude Spectrum')

