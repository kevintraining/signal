function [y,t] = mySumHarmonics(f0,nHarmonics)

oddNums = 1:2:(2*nHarmonics-1);
A = 1 ./ oddNums;   %Row vector of amplitude
f =(f0*oddNums).'; % Column vector of sin frquencies
fs =3*max(f);

%TODO Create the time vector t.
t = 0:1/fs:3/f0;
%TODO Use a for-loop to generate the sum of sine waves
y = A*sin(2*pi*f*t);
%TODO plot your signal
plot(t,y);






end