function [y,t] = sumHarmonics(f0,nHarmonics)

oddNums = 1 : 2 : (2*nHarmonics-1);
A = 1 ./ oddNums;        % Row vector of amplitudes
f = (f0 * oddNums).';    % Column vector of sine frequencies
fs = 3 * max(f);         % Define a sampling rate (3x Max Frequency)
t = 0 : 1/fs : 3 * 1/f0; % Define time vector for 3 cycles

% Approach 1: No For Loop
y = A * sin(2*pi*f*t);

% Approach 2: With For Loop
%y = zeros(size(t));
%for i = 1:length(f)
%    y = y + A(i)*sin(2*pi*f(i)*t);
%end

plot(t,y);

end