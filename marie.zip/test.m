%% Section1
[y,t] = sumHarmonics(100,10);
Y = fft(y,2^17)

% Note: fs is computed as 5700 in sumHarmonics
f = fftf(length(Y),5.7e3);
plot(f,fftshift(abs(Y)));

%% Section2
M = 4;
Fs = 100;
x = ones(1,M);
X = fft(x,2^17)

f = [0 1 2 3] / 4 * Fs