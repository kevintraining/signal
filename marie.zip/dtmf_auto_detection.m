%% Clear all variables.
clear


%% Load signal into MATLAB.
[phone, fs] = audioread('files\chapter6\phonedial.wav');
NDigits     = 10;


%% Find digit boundaries.
%
% * Use rms (i.e. average power) as metric to detect each burst.
%
% * There are 10 digits and so there are 20 change points to detect.
%
ipt = findchangepts(phone, 'Statistic', 'rms', 'MaxNumChanges', NDigits*2);
figure(1)
clf
plot(phone)
hold on
for n = 1:length(ipt)
    plot([1 1]*ipt(n), [-0.6 0.6], 'r');
end


%% Do DTMF decoding in frequency domain for each digit.
%
% * For each burst, we need to find out the two DTMF tone frequencies and then
%   map these two frequencies to the phone digit.
%
n1 = 1;
n2 = 2;
y  = [];
for digit = 1:NDigits
    
    % Get samples for one burst.
    m1 = ipt(n1);
    m2 = ipt(n2);
    x  = phone(m1:m2);

    % Spectral analysis.
    [P, f] = pwelch(x, kaiser(length(x), 20), [], 2^17, fs);
    
    % Find the two peak frequencies.
    [pks, locs] = findpeaks(P);         % Return about 400 peaks.
    [~, m]      = maxk(pks, 2);         % Only look for 2 peaks.
    fpeak       = f(locs(m));           % Dual frequencies.
    
    % Map the two peak frequencies to a single digit.
    lowband  = [697  770  852  941];
    highband = [1209 1336 1477 1633];
    [~, row]  = min(abs(fpeak(1) - lowband));
    [~, col]  = min(abs(fpeak(2) - highband));
    K         = ['1', '2', '3', 'A';    ...
                 '4', '5', '6', 'B';    ...
                 '7', '8', '9', 'C';    ...
                 '*', '0', '#', 'D'];
    y         = [y, K(row,col)];
    
    % Increment n1 and n2 to move onto next burst.
    n1 = n1 + 2;
    n2 = n2 + 2;

end


%% Pretty print y.
y = [y(1:3), '-', y(4:6), '-', y(7:10)]






