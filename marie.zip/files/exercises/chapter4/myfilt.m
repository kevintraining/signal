%% load signal into workspace
load filtsig
plot(y(1:160))
hold on

%% filter signal with notch filter
fx1=filter(b,a,y);
plot(fx1(1:160),'r')

%% Use filtfilt 
fx2=filtfilt(b,a,y);
plot(fx2(1:160),'k')
legend({'Original','First principles','Filtfilt'})

%% Suppose we can't do filtering in one go
% Filter the signal in sections, calling filter() for each section
% successively.
sec1=y(1:end/2);
sec2=y(end/2+1:end);
fxsec1=filter(b,a,sec1);
fxsec2=filter(b,a,sec2);
figure
plot([fxsec1, fxsec2])

%% That one didn't work very well because you didn't maintain the filter
%  states betwwen calls. Do it again, but now maintain filter states.
[fxsec1,xi]=filter(b,a,sec1);
fxsec2=filter(b,a,sec2,xi);
hold on 
plot([fxsec1, fxsec2],'r')
legend({'Without saving states','Saving states'})