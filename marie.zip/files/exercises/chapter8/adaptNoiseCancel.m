%% Solution to MLSG Exercise: Adaptive Noise Cancellation

%% Read in WAV file of clean signal
[s,Fs] = audioread('mod_theme.wav');
soundsc(s,Fs)

%% Read in WAV file of ambient noise
[x,fs] = audioread('mod_cabin.wav'); %input noise to filter
soundsc(x,fs)

% Check that the clean signal and the noise signal have the same sampling
% rate.
if (Fs ~= fs)
    error('Error: Input files differ in sampling rate');
end

%% Apply path filter to create colored noise
b = [1, 0.3, -0.5]; % Filter representing the headphone casing
z = filter(b,1,x); % Noise coming through the headphone casing
d = s + z; % Noisy signal = Clean signal + Noise through the headphone casing
soundsc(d,fs)

%%  The adaptive filter
hLMSFilt = dsp.LMSFilter; % Create an adaptive filter System object
hLMSFilt.Length = 5;
hLMSFilt.StepSize = 0.1;
% Find filter such that filtered x matches z in Least Squares sense
[y,e,w] = step(hLMSFilt,x,d);
% y represents the filtered noise estimate
% e represents the clean signal estimate

% Compare the frequency responses of the actual filter and the estimated
% filter.
fvt = fvtool(b,1,w,1);
legend(fvt,'Actual filter','Estimated filter');

%% Listen to the clean signal estimate
soundsc(e,fs)

%% Listen to the filtered noise estimate
soundsc(y,fs)

%% Listen to the clean signal (s) plus what the adaptive filter sends (-y)
%  to the headphones
soundsc(s-y,fs)

%% Listen to what the person hears with the noise coming through the
%  headphone casing added
soundsc(s-y+z,fs)