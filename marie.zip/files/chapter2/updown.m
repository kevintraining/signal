%% Load and listen to the original sound
load mtlb
soundsc(mtlb,Fs)
%% Downsample by 4 and listen
mtlb_down4 = downsample(mtlb,4);
soundsc(mtlb_down4,Fs/4);
%% Decimate by 4 and listen
mtlb4_decim4 = decimate(mtlb,4);
soundsc(mtlb4_decim4,Fs/4);
%% Try with upsample and listen
mtlb_up4 = upsample(mtlb,4);
soundsc(mtlb_up4,Fs*4);
%% Interpolate by 4 and listen
mtlb_int4 = interp(mtlb,4);
soundsc(mtlb_int4,Fs*4);
