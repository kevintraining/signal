%% Decimation using IFIR filter
%
% Specifications
fs = 100e3; % Sampling rate
M = 50; % decimation factor
Rp = 0.005; % passband ripple
As = 80; % stopband attenuation

% Compute required Fstop for the antialiasing filter
fstop = (fs/2)/M %#ok<*NOPTS>
% Set Fpass at 95% of Fstop
fpass = 0.95*fstop

%% Design single stage lowpass filter for decimation
d = fdesign.lowpass(fpass,fstop,Rp,As,fs)
Hd_single = design(d,'kaiserwin');
info(Hd_single)
cost_single = cost(Hd_single)

%% Design the IFIR decimator following the steps in the course manual.
% Factorize 50 = 25*2
M1 = 25; M2 = 2;
%  Design stretched filter S(z) using stretch factor of M1
Spass = fpass*M1;
Sstop = fstop*M1;
dS = fdesign.lowpass(Spass,Sstop,Rp/2,As,fs)
Hd_S = design(dS,'kaiserwin');
info(Hd_S)
cost_S = cost(Hd_S)

%% Design image rejection filter L(z)
Lstop = fs/M1 - fstop;
Lpass = fpass;
dL = fdesign.lowpass(Lpass,Lstop,Rp/2,As,fs);
Hd_L = design(dL,'kaiserwin');
info(Hd_L)
cost_L = cost(Hd_L)

%% Design IFIR decimator using fdesign
dDecim = fdesign.decimator(50,'Lowpass',fpass,fstop,Rp,As,fs);
H_IFIR = design(dDecim,'ifir','SystemObject',true)
info(H_IFIR)
cost_IFIR = cost(H_IFIR)
Hi1 = H_IFIR.Stage1
Hi2 = H_IFIR.Stage2

%% Examine responses and implementation details
hfvt1 = fvtool(Hd_single,Hd_S,Hd_L);
legend(hfvt1,'Single stage','IFIR S(z)','IFIR L(z)');
hfvt2 = fvtool(H_IFIR);
legend(hfvt2,'IFIR designed by fdesign');
addfilter(hfvt2,Hi1,Hi2);
legend(hfvt2,'Overall','Stage 1','Stage 2');

%% Test by decimating a signal
t = (0:1/fs:(0.5 - 1/fs))';
x = sin(2*pi*100*t) + 0.5*sin(2*pi*200*t);

% Decimation with single rate filter
x1 = filter(Hd_single,x); % filter
y1 = downsample(x1,M); % downsample

% Decimation with IFIR filter constructed manually
v1 = filter(Hd_L,x);
v1d = downsample(v1,M1);
v2 = filter(Hd_S,v1d);
y2 = downsample(v2,M2);

% Decimation with IFIR filter designed with 'ifir'. Explicitly call the STEP
% method for each stage to apply filtering. This is because a STEP method is not
% supported for object dsp.FilterCascade.
tmp = step(H_IFIR.Stage1,x);
y3  = step(H_IFIR.Stage2,tmp);

%% plot decimation outputs
figure; 
plot(y1); 
grid on; hold on; 
plot(y2,'r'); 
plot(y3,'g'); 
hold off;
legend('single stage','Hand crafted IFIR','IFIR with fdesign');

% Plot the PSD of the decimated signals
Pyy2 = pwelch(y2,[],[],4096,fs/M);
Pyy3 = pwelch(y3,[],[],4096,fs/M);
figure; 
plot(10*log10(Pyy2)); 
hold on; grid on; 
plot(10*log10(Pyy3),'r'); 
hold off;
legend('Hand crafted IFIR','IFIR with fdesign');