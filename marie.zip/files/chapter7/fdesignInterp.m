%% Design an interpolating filter for interpolation by L
L = 3;
interpSpec = fdesign.interpolator(L) %#ok<*NOPTS>
interpFilt = design(interpSpec,'kaiserwin','SystemObject',true);
fvtool(interpFilt,'Analysis','info')

%% Create a noisy tone signal to test the interpolator
fs = 8000; % sampling rate
f = 500;   % frequency of the tone
t = (0:1/fs:1)';
x = sin(2*pi*f*t) + 0.2*randn(length(t), 1);
% Interpolate the signal by factor L
xInt = step(interpFilt,x);
% Plot PSDs before and after interpolation keeping the sampling rates in
% mind.
pwelch(x,[],[],[],fs);
title('PSD of the signal before interpolation');
figure;
pwelch(xInt,[],[],[],fs*L);
title('PSD of the signal after interpolation');