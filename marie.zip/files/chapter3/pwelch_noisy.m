%% Compare "periodogram" vs. "pwelch"
% Run this program several times and observe the plots each time. What do
% you see?
% Increase the signal duration, T, to get longer signal, does it
% change anything?
% Decrease the signal duration parameter T to zero, and
% execute program multiple times. Do you see anything different?
%
Fs = 1000;
T = 0; % signal duration in seconds
t = 0:1/Fs:max(.6,T); % put a lower limit of more than 
%                       512 samples on signal length
% Create noisy signal as a sum of two sinusoids and noise
x = cos(2*pi*t*200)+cos(2*pi*t*210)+0.5*randn(size(t));
% Compute and display periodogram with 512-point FFT and
% rectangular window (default)
figure(1); periodogram(x,[],512,Fs,'onesided');
% Compute and display Welch estimate with 512 point FFT and
% Hamming window (default)
figure(2); pwelch(x,512,128,512,Fs);
