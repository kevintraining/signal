function directstop(n)

% DIRECTSTOP Computes an nth-order filter using least-squares fit to 
% a desired frequency response.

% Desired response:
f  = [0 0.3 0.3 0.4 0.4 0.5 0.5 0.6 0.6 1];
m = [1 1 0.5 0.5 0 0 0.5 0.5 1 1];

% Compute filter coefficients and frequency response:
[b,a] = yulewalk(n,f,m);
[h,w] = freqz(b,a,128);

% Overplot desired and actual frequency responses:
plot(f,m,'ro--',w/pi,abs(h),'b-')
legend('Desired',['Yule-Walker Design: Order ', num2str(n)])
title('Comparison of Response Magnitudes')