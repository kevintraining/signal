%% Reducing Filter Delay
% Reduce filter delay by converting linear phase FIR filters to minimum
% phase FIR filters.
Fs = 16000;
n = 62;
wn = 0.4;
% Design window based low pass FIR filter
b = fir1(n,wn);
%% Reflect all zeros inside unit circle to create minimum phase filter
bmin = polystab(b);
bmin = bmin * norm(b)/norm(bmin);
%% Observe filter properties, such as, frequency response, pole-zero plot,
% group delay over pass band, impulse response, etc.
% Note the lower group delay and how most of the filter impulse response is
% concentrated towards the beginning for the minimum phase filter.
fvtool(b,1,bmin,1)
