function mypsd(x, Fs)

if length(x) < 8192
    L = length(x);
else
    L = 8192;
end

pwelch(x, kaiser(L, 20), [], 2^17, Fs, 'centered');

end
