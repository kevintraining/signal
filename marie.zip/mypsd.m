function mypsd(x, Fs)
[P,f] = pwelch(x,kaiser(8192,20),[],2^17,Fs,'centered');
figure
plot(f,10*log10(P))
end