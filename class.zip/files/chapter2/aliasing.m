%% Script showing sampling of a continuous signal and aliasing
%
f = 5; % Experiment with a 5Hz sine wave
fsa = 1000; % Set a high sampling rate to plot the analog signal
t = 0:1/fsa:2;
xa = sin(2*pi*f*t); % The analog signal (approximate)
plot(t,xa,'LineWidth',2); % Plot the analog signal (approximate)
hold on;

fs1 = 15; % sampling rate > 2*f
ts1 = 0:1/fs1:2;
xs1 = sin(2*pi*f*ts1);
plot(ts1,xs1,'ro-');

fs2 = 7.5; % sampling rate < 2*f
ts2 = 0:1/fs2:2;
xs2 = sin(2*pi*f*ts2);
plot(ts2,xs2,'k^-','LineWidth',2); hold off;
title('\bf5Hz sampled sinusoid','FontSize',12);
legend('Analog signal (f = 5)','f_s = 15Hz > 2f','f_s = 7.5Hz < 2f');