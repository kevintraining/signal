%% Experiment with frequency resolution and zero-padding
fs = 1000;
N = 1024; % FFT size
t = (0:N-1)/fs;
% Create a sum of sine waves 2 Hz apart. If we
% use all the 1024 data points to compute an FFT,
% we should be able to resolve these frequencies since
% fs/N = 1000/1024 = 0.9766 Hz.
x = sin(2*pi*100*t) + sin(2*pi*102*t);
X = fft(x);
% Generate the frequency vector at which DFT is computed
f = fs*(0:N-1)/N;
% Check that we can see both frequencies in the FFT (zoom around the peaks
% to see if two peaks could be resolved)
plot(f,20*log10(abs(X))); grid on;
title([num2str(N),' point FFT with ',num2str(N),' data points']);
%%
% We shouldn't be able to resolve these
% frequencies if we used 256 data points
% since fs/N will become 3.9063 Hz, i.e. the
% minimum bin size is wider than the frequency
% separation of sines in our signal. Check it out.
N = 256;
x256 = x(1:N);
X256 = fft(x256);
% Generate the frequency vector at which DFT is computed
f = fs*(0:N-1)/N;
figure; plot(f,20*log10(abs(X256))); grid on;
title([num2str(N),' point FFT with ',num2str(N),' data points']);
%%
% Pad zeros to the 256 data points
% to take a 1024 point FFT. This will
% interpolate the spectrum computed
% earlier with 256 point FFT but
% interpolation cannot add extra information
% and hence should not be able to resolve
% the two frequency components in the signal.
N = 1024;
X256p = fft(x256,N);
% Generate the frequency vector at which DFT is computed
f = fs*(0:N-1)/N;
figure; plot(20*log10(abs(X256p))); grid on;
title([num2str(N),' point FFT with 256 data points']);
%%
% Pad zeros to the original 1024 data points
% to interpolate the spectrum and see
% the two frequency components more clearly.
N = 4096;
Xp = fft(x,N);
% Generate the frequency vector at which DFT is computed
f = fs*(0:N-1)/N;
figure; plot(f,20*log10(abs(Xp))); grid on;
title([num2str(N),' point FFT with 1024 data points']);

