%% 1. Create 3-second signal with 3 sine waves starting with different delays
fs = 8192;
A = [0.5, 0.3, 0.2]; % Amplitudes (row vector)
f = [220; 300; 440]; % Frequencies (column vector)
t =  0:1/fs:3; % (row vector)

% Create logical indexing arrays for gating the signals:
b(1,:) = (t >= 0); % Time base for 220 Hz
b(2,:) = (t > 1);  % Time base for 300 Hz
b(3,:) = (t > 2);  % Time base for 440 Hz

% Create the sum of three tones using the array 'b' to control
% their starting times
x = A*(b.*sin(2*pi*f*t)); % Three-tone signal

% Plot and play the signal
plot(t,x)
title('Three-Tone Signal')
sound(x,fs)

%% 2. Generate white noise with standard deviation of 0.1
n = 0.1*randn(size(t));
noiseMean = mean(n) %#ok<*NOPTS> % Check for zero mean
noiseSTD = std(n) % Check the standard deviation

%% 3. Add noise to the sum of tones and plot
y = x + n;
figure
plot(t,y)
title('Three-Tone Signal with Noise')