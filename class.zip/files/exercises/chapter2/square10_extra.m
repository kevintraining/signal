%% Generate a 2Hz square wave with 10% duty cycle sampled at 8000Hz for a
%  duration of 2 seconds.
fs = 8000;
t = 0:1/fs:2;
% Add a phase offset and see what happens
x = square(2*pi*2*t+pi/4,10);
y = sin(2*pi*2*t+pi/4);
plot(t,x,'LineWidth',2); hold on;
plot(t,y,'r'); grid on; hold off;
axis([-0.1 2.1 -1.1 1.1]); % Set plot axis limits for better display