function f = fftf(N, fs_Hz, flag)

%%
%       SYNTAX: f_Hz = fftf(N, fs_Hz);
%               f_Hz = fftf(N, fs_Hz, flag);
%               status = fftf('selftest');
%
%  DESCRIPTION: Calculate FFT frequencies in Hz.
%
%               status = fftf('selftest') runs selftests.
%
%        INPUT: - N (real double)
%                   FFT length. N >= 0.
%
%               - flag (string)
%                   Flag. Optional. Default = 'two-sided'. Valid strings are:
%                       'two-sided' - Two-sided frequencies from -0.5*fs_Hz to
%                                     0.5*fs_Hz. Note that the two end
%                                     frequencies (-0.5*fs_Hz and 0.5*fs_Hz) may
%                                     not be included in the output variable
%                                     "f".
%                       'one-sided-whole' - One side frequencies from 0 to
%                                           a frequency which is slightly less
%                                           than fs_Hz.
%                       'one-sided-half' - One side frequencies from 0 to a 
%                                          frequency which is exactly equal to
%                                          0.5*fs_Hz (in case N is even) or a
%                                          frequency which is slightly less than
%                                          0.5*fs_Hz (in case N is odd).
%
%               - fs_Hz (real double)
%                   Sampling rate in Hz.
%
%       OUTPUT: - f_Hz (1-D row vector of real double)
%                   Vector of FFT frequencies in Hz.
%
%               - status (real double)
%                   Test status. Valid values are:
%                       1 - Test passes.
%                       0 - Test fails.


%% Perform selftest.
if (nargin == 1) && ischar(N)
    f = fftf_selftest;
    return;             % Early exit.
end


%% Use default value for "flag"?
if nargin == 2
    flag = 'two-sided';
end


%% Calculate FFT normalized frequencies.
if N == 0
    f = [];
else
    switch flag
    case 'two-sided'
        if mod(N,2) == 0
            % N = even.
            M = N / 2;
            k = ((-M) : (M-1));
        else
           % N = odd.
           M = (N - 1)/2;
           k = ((-M) : M);
        end
    case 'one-sided-whole'
        k = 0 : (N-1);
    case 'one-sided-half'
        if mod(N,2) == 0
            % N = even.
            M = N / 2;
            k = (0 : M);
        else
            % N = odd.
            M = (N - 1)/2;
            k = (0 : M);
        end
    otherwise
        error('Invalid flag.');
    end
    f = k / N;
end


%% Convert normalized frequency to frequency in Hz.
f = f * fs_Hz;


end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     FUNCTION: fftf_selftest - Test fftf.
%
%       SYNTAX: status = fftf_selftest;
% 
%  DESCRIPTION: Test fftf.
%
%        INPUT: none.
%
%       OUTPUT: - status (real double)
%                   Test status. Valid values are:
%                       1 - Test passes.
%                       0 - Test fails.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function status = fftf_selftest


%% Initialize status.
status = 1;


%% Test: N = 0.
N     = 0;
fs_Hz = 1;
flag  = 'two-sided';
f     = fftf(N, fs_Hz, flag);
if ~isempty(f)
    status = 0;
end


%% Test: N = 3. two-sided.
N       = 3;
fs_Hz   = 1;
flag    = 'two-sided';
f       = fftf(N, fs_Hz, flag);
ideal_f = (-1:1) / 3;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 4. two-sided.
N       = 4;
fs_Hz   = 1;
flag    = 'two-sided';
f       = fftf(N, fs_Hz, flag);
ideal_f = (-2:1) / 4;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 7. two-sided.
N       = 7;
fs_Hz   = 1;
flag    = 'two-sided';
f       = fftf(N, fs_Hz, flag);
ideal_f = (-3:3) / 7;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 8. two-sided.
N       = 8;
fs_Hz   = 123;
flag    = 'two-sided';
f       = fftf(N, fs_Hz, flag);
ideal_f = (-4:3) / 8 * fs_Hz;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 3. one-sided-whole.
N       = 3;
fs_Hz   = 1;
flag    = 'one-sided-whole';
f       = fftf(N, fs_Hz, flag);
ideal_f = (0:2) / 3;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 4. one-sided-whole.
N       = 4;
fs_Hz   = 1;
flag    = 'one-sided-whole';
f       = fftf(N, fs_Hz, flag);
ideal_f = (0:3) / 4;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 3. one-sided-half.
N       = 3;
fs_Hz   = 1;
flag    = 'one-sided-half';
f       = fftf(N, fs_Hz, flag);
ideal_f = (0:1) / 3;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 4. one-sided-half.
N       = 4;
fs_Hz   = 1;
flag    = 'one-sided-half';
f       = fftf(N, fs_Hz, flag);
ideal_f = (0:2) / 4;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 7. one-sided-half.
N       = 7;
fs_Hz   = 1;
flag    = 'one-sided-half';
f       = fftf(N, fs_Hz, flag);
ideal_f = (0:3) / 7;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 8. one-sided-half.
N       = 8;
fs_Hz   = 1;
flag    = 'one-sided-half';
f       = fftf(N, fs_Hz, flag);
ideal_f = (0:4) / 8;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


%% Test: N = 3. two-sided.
N       = 3;
fs_Hz   = 109;
f       = fftf(N, fs_Hz);
ideal_f = (-1:1) / 3 * 109;
if max(abs(f - ideal_f)) > 0
    status = 0;
end


end

