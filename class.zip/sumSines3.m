function x = sumSines3

%% Generate sum of sinusoids
A  = [1, 1/3, 1/5, 1/7, 1/9];   % Amplitudes
f  = [100; 300; 500; 700; 900]; % Frequencies
fs = 8000;                      % Sampling rate
t  = 0:1/fs:500;

x = zeros(1, length(t));
for k = 1:length(A)
    x = x + A(k)*sin(2*pi*f(k)*t);
end

end
