%% Clear all variables.
clear

%% Create single tone signal.
t = (0 : 1e5) / 100;
x = sin(2*pi*30*t);
figure(1)
clf
mypsd(x, 100);

%% Insert one zero between each sample.
% TODO
figure(2)
clf
mypsd(y, 200);

%% Lowpass filter signal y.
% TODO
figure(3)
clf
mypsd(u, 200);


