%% Make it a cell so that we can make edits and run it 
%  without saving the file.
fs = 1000;
% Choose a short duration
t = 0:1/fs:0.1;
% Create the signal
x = sin(2*pi*250*t) + sin(2*pi*200*t) + sin(2*pi*100*t);
rng(1134, 'mt19937ar');
xn = x + randn(size(x));
% Compute spectrum with subspace methods
figure(1); peig(xn,6,[],fs);
figure(2); pmusic(xn,6,[],fs);
% Compare with Welch's method
figure(3); pwelch(xn,[],[],[],fs);
