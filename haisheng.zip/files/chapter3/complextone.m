%% Clear all
clear
%% Create signal x[n]
Fs = 100;
t = (0:3)/Fs;
x = exp(1i*2*pi*10*t);
%% Calculate FFT.
X = fftshift(fft(x, 2^17));
f= fftf(length(X), Fs);

%%Plot FFT
figure(1)
plot(f, abs(X))