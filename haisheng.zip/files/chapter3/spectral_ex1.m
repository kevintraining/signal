clear

Fs = 100;
t = (0:3) / Fs;
x1 = exp(1i*2*pi*10*t);
%Create discrete time signal x2[n] - complex tone at -10Hz. Fs = 100Hz.
Fs = 100;
t = (0:3)/Fs;
x2 = exp(1i*2*pi*10*t);

X1 = fftshift(fft(x1, 2^17));
f1 = fftf(length(X1), Fs);
