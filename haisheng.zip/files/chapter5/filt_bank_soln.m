function y = filt_bank(k1,k2,k3,k4,k5,k6,x,Fs)

% FILT_BANK takes in 6 filter gains, k1,k2,...,k6
% Also it takes in data, x, and sampling frequency, Fs
% FILT_BANK processes data, x, through a filter bank
% and returns output signal, y, and plays it on speakers
% A FILTERS.MAT file is required to contain 6 filter objects
load Filters.mat

x1=filter(Hd1,x)*k1;
x2=filter(Hd2,x)*k2;
x3=filter(Hd3,x)*k3;
x4=filter(Hd4,x)*k4;
x5=filter(Hd5,x)*k5;
x6=filter(Hd6,x)*k6;

y=x1+x2+x3+x4+x5+x6;

% Listen to the filtered signal
soundsc(y,Fs)