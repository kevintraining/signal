function [y, t] = mySumHarmonics(f0, nHarmonics)
oddNums = 1:2:(2*nHarmonics -1);
A       = 1./oddNums; %Row vector of amplitudes.
f       =(f0 * oddNums).'; %column vector of sine frequencies.
fs      = 3*max(f);

%TODO: Create the time vector t.
t = 0:1/fs: 3/f0;
%TODO: Use a for-loop to generate the sum of sine waves. Or you can
%      vectorize your code(i.e. no for loop).
y = zeros(size(t));
for n = 1:nHarmonics
    y = y + A(n)*sin(2*pi*f(n)*t);
end
%TODO: pLOT YOUR SIGNAL.
figure(1)
plot(t, y)
end

