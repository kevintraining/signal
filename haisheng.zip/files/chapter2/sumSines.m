%% Generate sum of sinusoids
A = [1, 1/3, 1/5, 1/7, 1/9]; % Amplitudes
f = [100; 300; 500; 700; 900]; % Frequencies
fs = 8000; % Sampling rate
t = 0:1/fs:0.03;
x = A*sin(2*pi*f*t);
plot(t,x);
