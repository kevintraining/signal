%% Generate time base
fs = 10;
t = 0:1/fs:1;
%% Unit impulse
x1 = [1; zeros(length(t)-1,1)];
%% Unit step
x2 = ones(length(t),1);
%% Ramp
x3 = 2*t';
