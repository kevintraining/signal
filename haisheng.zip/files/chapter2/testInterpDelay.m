%% Interp/decimate experiment for delays. Try with diferent interpolation
% factors and delays. Try changing the signal 'x' (not violating the
% sampling theorem of course).
fs = 8000;
f = 100;
t = 0:1/fs:1;
x = 0.5*cos(2*pi*f*t) + sin(2*pi*2*f*t);
% Specify interpolation factor and delay
factor = 4;
delay = 10 %#ok<*NOPTS>
% Interpolate signal
xi = interp(x, factor);
% Compute delay for the interpolated signal
delayi = factor * delay;
% Add delay
yi = [zeros(1, delayi), xi];
% Decimate delayed signal
y1 = decimate(yi, factor);
y2 = decimate(yi, factor, 'fir');
plot(x(1:100), '-o'); hold on; grid on;
plot(y1(1:100), '-+');
plot(y2(1:100), 'r-o'); hold off;
legend('original','decimate filtfilt','decimate fir');
%% Find delay through xcorr
[rxy1,lag] = xcorr(y1,x);
[rxy2,lag] = xcorr(y2,x);
[~, indx1] = max(rxy1);
[~, indx2] = max(rxy2);
% Now get the original delay
d1 = lag(indx1)
d2 = lag(indx2)