%% Generate sinusoid
% Using an audio frequency sample rate of 4kHz, generate a tone at 1kHz.
fs = 1e3;
t = (0:1/fs:1)';
f0 = 10;
signal = sin(2*pi*f0*t);
% pulses = bias + 0.5*squarewave
pulses = 0.5 + 0.5*square(2*pi*4*t,70);

% Apply pulse
sigPulse = signal .* pulses;
plot(sigPulse,'LineWidth',2);
axis([-100 1100 -1.5 1.5]);
fs_mod = 4e3;
sigInterp = interp(sigPulse,fs_mod/fs);

%% Modulation
% Using an amplitude modulation here for simplicity. For radio, AM tends to
% be used at the medium wave band and phase or frequency modulation at HF.
modType = 'amdsb-sc';
fc = 1000;
sigMod = modulate(sigInterp,fc,fs_mod,modType);
figure; plot(sigMod);
axis([-400 4400 -1.5 1.5]);