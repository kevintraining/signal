%% Generate a number of sine waves and add them

fs = 2000;    % Sampling rate
t = 0:1/fs:3; % Time base
% Generate sine waves and add them
x = 10*sin(2*pi*50*t) + sin(2*pi*950*t); % Signal
plot(t,x)
title('High and Low')
soundsc(x,fs)