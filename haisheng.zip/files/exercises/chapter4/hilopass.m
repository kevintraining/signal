%% Generate the signal x (run 'hilo' from earlier exercise)
hilo % Generate signal x.
axis([0 0.1 -11 11]) % zoom into a portion of x
pause(3); % Let the sound play out

%% Enter filter coefficients
bLo = [0.5 0.5];
bHi = [0.5 -0.5];
% plot the frequency responses
figure
freqz(bLo,1)
title('Low Pass Filter')
figure
freqz(bHi,1)
title('High Pass Filter')

%% Filter the signal with each filter
yLo = filter(bLo,1,x);
yHi = filter(bHi,1,x);
% Plot and listen to the filtered signals
%% Lowpass:
figure
plot(t,yLo,'r')
axis([0 0.1 -11 11])
title('Low Pass Output')
pause(3)
sound(yLo,fs)
%% Highpass:
figure
plot(t,yHi,'r')
axis([0 0.1 -11 11])
title('High Pass Output')
pause(3)
sound(yHi,fs)

%% Create pole-zero plots for the two filters
% Compute pole and zero locations
[zLo,pLo,kLo] = tf2zpk(bLo,1);
[zHi,pHi,kHi] = tf2zpk(bHi,1);
% Plot them
figure
zplane(zLo,pLo)
title('Low Pass Filter')
%
figure
zplane(zHi,pHi)
title('High Pass Filter')