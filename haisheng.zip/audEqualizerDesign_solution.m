clear all

Fs = 8192;

d1 = fdesign.lowpass(130, 131, 1, 40, Fs);

d2 = fdesign.bandpass(129,  130,  260,  262,  40, 1, 40, Fs);
d3 = fdesign.bandpass(258,  260,  520,  524,  40, 1, 40, Fs);
d4 = fdesign.bandpass(516,  520,  1040, 1048, 40, 1, 40, Fs);
d5 = fdesign.bandpass(1032, 1040, 2090, 2096, 40, 1, 40, Fs);

d6 = fdesign.highpass(2084, 2090, 40, 1, Fs);

Hd1 = design(d1,'ellip');
Hd2 = design(d2,'ellip');
Hd3 = design(d3,'ellip');
Hd4 = design(d4,'ellip');
Hd5 = design(d5,'ellip');
Hd6 = design(d5,'ellip');

fvtool(Hd1)
