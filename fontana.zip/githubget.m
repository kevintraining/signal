function githubget(varargin)

%% Get svn.exe path.
p      = fileparts(mfilename('fullpath'));
svnexe = fullfile(p, 'svn', 'svn.exe');

%% Export file from GITHUB.
x   = ['https://github.com/cykhung/tmp.git/trunk/', strjoin(varargin, ' ')];
cmd = [svnexe, ' export ', x];
dos(cmd);

end

