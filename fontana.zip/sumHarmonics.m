function [y,t]  = sumHarmonics(f0,nb_harm)

oddNums = 1 : 2 : (2*nb_harm -1);
A = 1./ oddNums;
f = (f0 .* oddNums)';
fs = 100 * max(f);

t = 0:1/fs:3/f0;

y = A*sin(2*pi*f*t);
plot(t,y);
hold
plot(t,y,'ro')
end