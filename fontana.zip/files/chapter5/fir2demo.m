function fir2demo(n)

% FIR2DEMO computes and plots an nth-order FIR design to fit specified
% magnitude response.

% Desired frequency response:
f  = [0 0.3 0.3 0.4 0.4 0.5 0.5 0.6 0.6 1];
m = [1 1 0.5 0.5 0 0 0.5 0.5 1 1];

% Design FIR filter to fit desired frequency response:
b = fir2(n,f,m);
[h,w] = freqz(b,1,128); % Compute frequency response

% Overplot desired and actual responses:
plot(f,m,'ro--',w/pi,abs(h),'b-')
legend('Desired',['fir2 Design: Order ', num2str(n)])
title('Filter magnitude Response')