% FIRCLSDEMO Designs an order 50 bandpass filter using FIRCLS. 

n = 50;

% Give frequency-amplitude characteristics.
f = [0 0.4 0.8 1];
amp = [0 1 0];

% Add constraints on the upper and lower bounds 
% for the frequency response in each band:
up = [0.02 1.02 0.01];
lo = [-0.02 0.98 -0.01];

% Compute the filter approximation and plot the 
% magnitude response in each sub-band:
b = fircls(n,f,amp,up,lo,'plots');