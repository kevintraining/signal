%% Filter an audio .wav file with a specified filter and write the
% filtered output to another .wav file.

% Specify audio file names and frame size
infilename = 'music_ch1.wav';
outfilename = 'music_ch1_lowpass.wav';
framesize = 10000;

% Filter coefficients
b = [3.7918e-04, 2.8604e-04, 2.8604e-04, 3.7918e-04];
a = [1, -2.8447, 2.7148, -0.8688];

%% Create and configure a System object to read from the audio file.
hSigSource = dsp.AudioFileReader(...
    infilename,  ...
    'SamplesPerFrame', framesize, ...
    'PlayCount', 1, ...
    'OutputDataType', 'double');

%% Create and configure the IIR filter System object.
hFilt = dsp.IIRFilter(...
    'Numerator', b, ...
    'Denominator', a);

%% Create and configure a System object to write the filter output to
%  an audio file. Use the sample rate information from the file reader
%  System object.
hAudioWriter = dsp.AudioFileWriter(...
    outfilename,...
    'SampleRate',hSigSource.SampleRate);

%% Filter the sound and save the output in a file
while ~isDone(hSigSource)
  x = step(hSigSource);  % Read from audio file
  y = step(hFilt, x);    % Filter the signal
  step(hAudioWriter, y); % Write to the output file
end

%% Release System objects.
%  Here you call the release method on the System objects to close any
%  open files and devices.

release(hSigSource);
release(hAudioWriter);
