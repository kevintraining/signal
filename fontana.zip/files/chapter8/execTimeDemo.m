% Demonstration of execution time vs. filter length
n = menu('Warning: Program takes approximately one minute for plots to appear.',{'Proceed','Cancel'});

if n == 1
    % Generate arbitrary input and desired signals
    % (The inputs values themselves are not important; we are concerned
    % with the number of computations per sample in this demo)
    x = randn(1e6,1);
    d = randn(1e6,1);
    
    HA2 = dsp.LMSFilter('WeightsResetInputPort',true,'StepSizeSource','Input Port');
    HA_block2 = dsp.BlockLMSFilter('WeightsResetInputPort',true,'StepSizeSource','Input Port');
    
    
    % Filter lengths
    L = [10 20 50 100 200 500 1000 2000 5000];
        
    i = 0;% counter
    for Len = L
        % Increment counter
        i = i+1;
        
        % Release both adaptive filter objects so that non-tunable
        % properties can be changed
        releaseAll(HA2,HA_block2);
        
        % Change FIR filter length for both adaptive filters, and block
        % size for Block LMS filter
        HA2.Length = Len;
        HA_block2.Length = Len;
        HA_block2.BlockSize = Len;
        
        % Execute and time both algorithms, populate execution time vectors
        tic;step(HA2,x,d,0.1,false);HA_time(i,1) = toc;
        tic;step(HA_block2,x,d,0.1,false);HA_block_time(i,1) = toc;
    end
    releaseAll(HA2,HA_block2)
    
    % Visualize the absolute execution times of both filters vs. FIR filter
    % length and their ratio vs. FIR filter length
    figure
    subplot(2,1,1)
    plot(L,[HA_time,HA_block_time],'.-')
    title('Execution Time vs. Filter Length for LMS and Block LMS Filters')
    xlabel('Filter Length')
    ylabel('Execution Time (s)')
    legend('LMS Filter','Block LMS Filter','Location','NorthWest')
    
    subplot(2,1,2)
    plot(L,HA_block_time./HA_time,'.-')
    title('Ratio of Execution Time vs. Filter Length for LMS and Block LMS Filters')
    xlabel('Filter Length')
    ylabel({'Ratio of Block LMS to','LMS Execution Time'})
    
    clear HA2 HA_block2
end