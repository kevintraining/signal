% Observe the effect of varying FIR filter length:

load adaptAnalysis
% adaptAnalysis.mat contains backup signals x and d (constructed in the
% same manner as on page 8)

% Create new LMS filter
HA2 = dsp.LMSFilter;

% Set step size to be input to step() method
HA2.StepSizeSource = 'Input port';

% Set filter to take filter reset flag as input
HA2.WeightsResetInputPort = true;

figure
L = [8,16,32,64,128,256];% vector of FIR filter lengths
for i = 1:length(L)
    % Release system object to change filter length (non-tunable property)
    release(HA2)
    
    % Set FIR filter length
    HA2.Length = L(i);

    % Run LMS algorithm on entire inputs with varying filter length.  Time 
    % the duration of algorithm in each iteration
    tic
    [y,e,w] = step(HA2,x,d,1,true);
    toc
    % Note: higher complexity increases runtime 
    % (LMS algorithm requires 2 convolutions of length L(i) per sample, so
    % number of operations and execution time increase linearly with L(i))
    
    % Plot smoothed squared error on semilog axes to analyze convergence
    % behavior
    semilogy(filter(ones(500,1)/500,1,e.^2))
    
    % Plot all iterations on same axes
    hold all
end

legend(num2str(L'),'Location','Best')
xlabel('Sample Number')
ylabel('Filtered Square Error')
title('LMS Filter Convergence with Step Size = 3e-4 and Varying Filter Length')
grid on
hold off

clear HA2