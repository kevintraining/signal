%% Compute power spectrum using modified Periodogram.
%
fs = 8000; % Sampling rate
framesize = 1000; % Data length (change this value to change 
                  % frequency resolution)
NFFT = 1000; % FFT length (change this value to pad with zeroes)

% Create the System object for generating three sine functions.
hSin = dsp.SineWave('Frequency',[100,250,254],...
                    'Amplitude',[1,0.8,0.5],...
                    'SampleRate', fs);
hSin.SamplesPerFrame = framesize;

% Create the System object for the (modified) Periodogram.
hPeriodogram = dsp.SpectrumEstimator('SampleRate', hSin.SampleRate,...
                                     'SpectrumType','Power',...
                                     'FrequencyRange','onesided',...
                                     'FFTLengthSource','Property',...
                                     'FFTLength',NFFT);

% Run a dummy step to get the frequency vector from the System object
step(hPeriodogram,zeros(framesize,1));
% Get the frequencies at which the spectrum is computed
f = getFrequencyVector(hPeriodogram);

% Generate a noisy sine wave and compute its power spectrum.
for ii = 1:10
x = sum(step(hSin),2) + 0.1*randn(framesize,1); % Generate noisy sum of sine waves
Pxx = step(hPeriodogram, x); % Compute power spectrum
plot(f,10*log10(Pxx)); % Display result
grid on;
title('Power spectrum of the sum of 3 sine waves');
xlabel('Frequency(Hz)');
ylabel('Power (dB Watts)');
set(gca, 'ylim', [-70 0])
drawnow
pause(1)
end