%% Clear all variables.
clear
close all;
%% Create single tone signal.
t = (0 : 1e5) / 100;
x = sin(2*pi*10*t);
figure(1)
clf
mypsd(x, 100);

% %% Lowpass filter signal x.
% %TODO
% fvtool(h, 'Fs', 100)
% x = filter(h, 1, x);
% figure(3)
% clf
% mypsd(x, 100);

%% Keep every other sample.
% TODO'
y = downsample(x,4);
figure(2)
clf
mypsd(y, 100/4);



