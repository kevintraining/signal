% Utility function to release arbitrary number of DSP System Toolbox System
% Objects
function releaseAll(varargin)

for i = 1:length(varargin)
    if ~strncmp(class(varargin{i}),'dsp.',4)
        error(['All arguments must be DSP System Objects.  Argument #', ...
            num2str(i),' is of type ',class(varargin{i})]);
    end
    release(varargin{i});
end