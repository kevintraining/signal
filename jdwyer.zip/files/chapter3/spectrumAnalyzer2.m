%% This script demonstrates how to use a spectrum analyzer System object
%  to display the PSD of a time varying signal
fs = 8000;
frameSize = 1000;
rbw = 50;

%% Create a Chirp System object to work as the signal source
hChirp = dsp.Chirp; % System object with default properties
% Assign desired property values
hChirp.SweepDirection = 'Bidirectional';
hChirp.InitialFrequency = 100;
hChirp.TargetFrequency = 3000;
hChirp.TargetTime = 5;
hChirp.SweepTime = 5;
hChirp.SampleRate = fs;
hChirp.SamplesPerFrame = frameSize;

%% Create a spectrum analyzer System object
hsp = dsp.SpectrumAnalyzer; % System object with default properties
% Assign desired property values
hsp.SampleRate = fs;
hsp.SpectrumType = 'Power density';
hsp.PlotAsTwoSidedSpectrum = false;
hsp.RBWSource = 'Property';
hsp.RBW = rbw;
hsp.Window = 'Hamming';
hsp.OverlapPercent = 20;
hsp.ReducePlotRate = false; % make sure to set this up as "false"

%% Generate a frame of the chirp signal and display its spectrum using
%  the spectrum analyzer System object.
for n = 1:100
    % Generate a frame of chirp signal
    y = step(hChirp) + 0.1*randn(frameSize,1);
    % Display PSD using the spectrum analyzer
    step(hsp,y);
end