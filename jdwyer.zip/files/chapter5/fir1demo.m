% FIR1DEMO Shows the use of FIR1 for standard band FIR filter design.

% Filter specifications.
fs = 8000; % Sampling frequency
fe = [1000 1300 2210 2410]; % Band edges (Hz)
mags = [1 0 1]; % Magnitudes in bands (bandstop)
devs = [0.01 0.05 0.01]; % Maximum allowable deviation between the 
                         % frequency response of the output filter 
                         % and its desired amplitude, for each band

% Choose a Kaiser window.
% Find minimum filter order and optimal window for specifications:
[n,Wn,beta,type] = kaiserord(fe,mags,devs,fs);

% Compute filter coefficients with FIR1.
n1 = n + rem(n,2); % Specify an even filter order (odd filter length)
b1 = fir1(n1,Wn,type,kaiser(n1+1,beta),'noscale');
[H,f1] = freqz(b1,1,1024,fs);
plot(f1,abs(H))
grid on
hold on

% Try lower order designs for comparison.
n2 = 40;
b2 = fir1(n2,Wn,type,kaiser(n2+1,beta),'noscale');
[H,f2] = freqz(b2,1,1024,fs);
plot(f2,abs(H),'r')

n3 = 20;
b3 = fir1(n3,Wn,type,kaiser(n3+1,beta),'noscale');
[H,f3] = freqz(b3,1,1024,fs);
plot(f3,abs(H),'m')

legend(['Minimum Order: ',num2str(n1)],...
       ['Order: ',num2str(n2)],...
       ['Order: ',num2str(n3)])