%% IIRTYPES Plots the frequency responses of analog prototypes 
%  of various filter types.
%
% o Butterworth filter
% o Chebyshev Type I filter
% o Chebyshev Type II filter
% o Elliptic filter
% o Bessel filter
%
% Filters are lowpass with a cutoff at Omega = 1 rad/sec,
% order n = 5, passband ripple Rp = 0.5 dB, and stopband 
% attenuation Rs = 20 dB.

n = 5;
Rp = 0.5;
Rs = 20;

%% Butterworth filter
[z,p,k] = buttap(n);
w = logspace(-1,1,1000);
h = freqs(k*poly(z),poly(p),w);
semilogx(w,abs(h),'LineWidth',2)
grid on
xlabel('Frequency (\Omega rad/sec)')
ylabel('Magnitude')
title('Analog  Prototype: Butterworth Filter')

%% Chebyshev Type I filter
figure
[z,p,k] = cheb1ap(n,Rp);
w = logspace(-1,1,1000);
h = freqs(k*poly(z),poly(p),w);
semilogx(w,abs(h),'LineWidth',2)
grid on
xlabel('Frequency (\Omega rad/sec)')
ylabel('Magnitude')
title('Analog  Prototype: Chebyshev type I Filter')

%% Chebyshev Type II filter
figure
[z,p,k] = cheb2ap(n,Rs);
w = logspace(-1,1,1000);
h = freqs(k*poly(z),poly(p),w);
semilogx(w,abs(h),'LineWidth',2)
grid on
xlabel('Frequency (\Omega rad/sec)')
ylabel('Magnitude')
title('Analog  Prototype: Chebyshev type II Filter')

%% Elliptic filter
figure
[z,p,k] = ellipap(n,Rp,Rs);
w = logspace(-1,1,1000);
h = freqs(k*poly(z),poly(p),w);
semilogx(w,abs(h),'LineWidth',2)
grid on
xlabel('Frequency (\Omega rad/sec)')
ylabel('Magnitude')
title('Analog  Prototype: Elliptic Filter')

%% Bessel filter
figure
[z,p,k] = besselap(n);
w = logspace(-1,1,1000);
h = freqs(k*poly(z),poly(p),w);
semilogx(w,abs(h),'LineWidth',2)
grid on
xlabel('Frequency (\Omega rad/sec)')
ylabel('Magnitude')
title('Analog  Prototype: Bessel Filter')