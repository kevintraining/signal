%% Compare multistage design with a single stage design of an interpolating
%  filter for interpolation by L
L = 8;
interpSpec = fdesign.interpolator(L) %#ok<*NOPTS>
% List the design methods available for this filter specification
designmethods(interpSpec)
interpFilt = design(interpSpec,'kaiserwin','SystemObject',true);
fvtool(interpFilt,'Analysis','info')
%% Do a multistage design and compare
interpFiltMulti = design(interpSpec,'multistage','SystemObject',true);
fvtool(interpFiltMulti,'Analysis','info')
