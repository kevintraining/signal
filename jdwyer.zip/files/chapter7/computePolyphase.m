%%
M = 3; 
firFilt = fir1(51,0.25);
firFilt = firFilt(:); % Make it a column vector
FiltLength = length(firFilt);
%%
if (rem(FiltLength, M) ~= 0)
     nzeros = M - rem(FiltLength, M);
     % Append zeros to make the length divisible by M
     firFilt = [firFilt; zeros(nzeros,1)];
end
%%
len = length(firFilt);
nrows = len / M;
PolyphaseFilt = reshape(firFilt, M, nrows);
% Take transpose to get each subfilter in a column
PolyphaseFilt = PolyphaseFilt';
%%
plot(firFilt,'-o');
title('Original FIR filter');
figure;
hold all;
for k=1:M
    plot(PolyphaseFilt(:,k),'-o');
end
title('Polyphase components');
%%
fvt = fvtool(firFilt,1);
for k=1:M
    addfilter(fvt,PolyphaseFilt(:,k));
end