function status = mlsgSelftest(machineType)

%%
%       SYNTAX: status = mlsgSelftest;
%               status = mlsgSelftest(machineType);
%
%  DESCRIPTION: Go through all matlab files in the MLSG course.
%
%               The function assumes that user has already added MLSG course
%               folders into MATLAB search path.
%
%        INPUT: - machineType (string)
%                   Machine type. Valid types are:
%                       'trainer' - Trainer PC. 
%                       'student' - Student PC. Default.
%
%       OUTPUT: - status (real double)
%                   Status. Valid values are:
%                       0 - Fail.
%                       1 - Pass.


%% Assign input arguments.
if nargin == 0
    machineType = 'student';
end
    

%% Initialize status.
status = 1;


%% Test linspace.
if max(abs(linspace(0, 0.3, 4) - [0 0.1 0.2 0.3])) > 1e-16
    status = 0;
end


%% Test fftInteractive.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    close all
    delta1 = [1 zeros(1,11)];
    fftInteractive(delta1)
    close all
    clear delta1
end


%% Test positiveFFT.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    close all
    [X, freq] = positiveFFT(ones(1,10), 1,  16);    %#ok<ASGLU>
    close all
    clear X freq
end


%% Test centeredFFT.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    close all
    [X, freq] = centeredFFT(ones(1,10), 1, 16);     %#ok<ASGLU>
    close all
    clear X freq
end


%% Test playshow.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    h = playshow('fftdemo');
    playshow('#close', h);
    phone
    close all
    h = playshow('sunspots');
    playshow('#close', h);
end


%% Test spectrogram. Trainer machine only.
if strcmp(machineType, 'trainer')
    tmp = load('handel.mat');
    spectrogram(tmp.y, kaiser(100,5), 75, 512, tmp.Fs);
    close all
    clear tmp
end


%% Test spectrogram. Trainer machine only.
if strcmp(machineType, 'trainer')
    sysObjBurg;     % Call freqz to plot and this causes MATLAB to generate
                    % a hidden warning message.
end


%% Test tf2zpk and zplane. Trainer machine only.
if strcmp(machineType, 'trainer')
    b = [1 2];
    a = [1 0 0.2];
    [z, p, k] = tf2zpk(b,a);                %#ok<ASGLU>
    zplane(z,p);
    close all
    clear b a z p k
end


%% Test ellip. Trainer machine only.
if strcmp(machineType, 'trainer')
    [b, a] = ellip(10, 0.5, 80, 2200/4000, 'high');         %#ok<ASGLU>
    clear b a
end


%% Test windemo.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    windemo(20)
    windemo(50)
    windemo(100)
    close all
end


%% Test fir2demo.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    fir2demo(10)
    fir2demo(100)
    fir2demo(500)
    close all
end


%% Test fir2demo.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    directstop(10)
    directstop(20)
    directstop(30)
    close all
end


%% Test audEqualizerDesign.m and filt_bank_soln.m. Trainer machine only.
if strcmp(machineType, 'trainer')
    mlsgSelftestEnableWarning;
    audEqualizerDesign;
    y = filt_bank_soln(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, ones(1,1e3), 1e3); %#ok<NASGU>
    close all
    c = slsvWarningListener('get');
    if ~isempty(c)
        status = 0;
    end
    clear y
    mlsgSelftestDisableWarning;
end


%% Test audioread.
if strcmp(machineType, 'trainer')
    mlsgSelftestEnableWarning;
    [phonesig, fs] = audioread('phonedial.wav');        %#ok<ASGLU>
    [noisy, fs] = audioread('noisySig.wav');            %#ok<ASGLU>
    c = slsvWarningListener('get');
    if ~isempty(c)
        status = 0;
    end
    clear phonesig fs noisy
    mlsgSelftestDisableWarning;
end


%% Test sumOddHarmonics.m.
if strcmp(machineType, 'trainer')
    mlsgSelftestEnableWarning;
    [x, t] = sumOddHarmonics(100, 9);       %#ok<ASGLU>
    [x, t] = sumOddHarmonics(100, 90);      %#ok<ASGLU>
    [x, t] = sumOddHarmonics(100, 900);     %#ok<ASGLU>
    c = slsvWarningListener('get');
    if ~isempty(c)
        status = 0;
    end
    clear x t
    mlsgSelftestDisableWarning;
end


%% Run a subset of mfiles. Student machine only.
if strcmp(machineType, 'student')
    filenames = { ...
        'sineWave.m',               ...     % Chapter 2
        'sumSines.m',               ...     % Chapter 2
        'fftInterp.m',              ...     % Chapter 3
        'transferplot.m',           ...     % Chapter 4
        'iirtypes.m',               ...     % Chapter 5
        'computePolyphase.m',       ...     % Chapter 7
        };
    mlsgSelftestEnableWarning;
    for n = 1:length(filenames)
        selftest_mlsg_run(filenames{n});
        c = slsvWarningListener('get');
        if ~isempty(c)
            status = 0;
        end
    end
    mlsgSelftestDisableWarning;
end


%% Run all mfiles in each chapter. Trainer machine only.
if strcmp(machineType, 'trainer')
    filenames = getAllMfiles;
    mlsgSelftestEnableWarning;
    for n = 1:length(filenames)
        selftest_mlsg_run(filenames{n});
        %     switch filenames{n}
        %     case {'fdesignDecim.m', 'sysObjDecim.m', 'ifirDecim.m'}
        %         % I think there is a bug in LASTWARN. Workaround.
        %         if ~strcmp(lastwarn, ...
        %                 ['mfilt.firdecim will be removed in a future ', ...
        %                 'release. Use dsp.FIRDecimator instead.'])
        %             status = 0;
        %         end
        %     case 'fdesignInterp.m'
        %         % I think there is a bug in LASTWARN. Workaround.
        %         if ~strcmp(lastwarn, ...
        %                 ['mfilt.firinterp will be removed in a future ', ...
        %                 'release. Use dsp.FIRInterpolator instead.'])
        %             status = 0;
        %         end
        %     case {'multistageInterp.m', 'narrowbandLowpass.m'}
        %         % I think there is a bug in LASTWARN. Workaround.
        %         if ~strcmp(lastwarn, ...
        %                 ['mfilt.cascade will be removed in a future ', ...
        %                 'release. Use dsp.FilterCascade instead.'])
        %             status = 0;
        %         end
        %     otherwise
        %         if ~isempty(lastwarn)
        %             status = 0;
        %         end
        %     end
        c = slsvWarningListener('get');
        if ~isempty(c)
            status = 0;
        end
    end
    mlsgSelftestDisableWarning;
end


%% Delete output files.
filenames = { ...
    fullfile(pwd, 'Filters.mat'),       ...
    fullfile(pwd, 'music_ch1_lowpass.wav'),       ...
    fullfile(pwd, 'myBeepSig.mat'),       ...
    };
for n = 1:numel(filenames)
    if exist(filenames{n}, 'file') ~= 0
        delete(filenames{n});
        fprintf('Delete file "%s".\n', filenames{n});
    end
end


%% Reset FORMAT back to the default.
format


end



function selftest_mlsg_run(filename)

fprintf('Running %s ...\n', which(filename));

close all
run(filename);
close all

end


function mlsgSelftestEnableWarning

slsvWarningListener('enable');
slsvWarningListener('skip_disabled_warnings', true);
slsvWarningListener('clear');

end



function mlsgSelftestDisableWarning

slsvWarningListener('disable');

end



function filenames = getAllMfiles
 
%% Initialize filenames.
filenames = {};

%% Chapter 2.
filenames{end+1} = 'sineWave.m';
filenames{end+1} = 'sumSines.m';
filenames{end+1} = 'aliasing.m';
filenames{end+1} = 'synthSig.m';
filenames{end+1} = 'simplePlots.m';
filenames{end+1} = 'plotAndListen.m';
filenames{end+1} = 'updown.m';
filenames{end+1} = 'modsig.m';
filenames{end+1} = 'generatePulsedSignal.m';
filenames{end+1} = 'processPulsedSignal.m';
filenames{end+1} = 'streamingSine.m';

%% Chapter 3.
filenames{end+1} = 'fftInterp.m';
filenames{end+1} = 'pgrams.m';
filenames{end+1} = 'whaleFFT.m';
filenames{end+1} = 'windft.m';
filenames{end+1} = 'windowing.m';
filenames{end+1} = 'testzeropad.m';
filenames{end+1} = 'testpsd.m';
filenames{end+1} = 'testpsd2.m';
filenames{end+1} = 'pwelch_noisy.m';
filenames{end+1} = 'pwelch_clean.m';
filenames{end+1} = 'whyParametric.m';
filenames{end+1} = 'testpeig.m';
filenames{end+1} = 'sysObjPSD.m';
% filenames{end+1} = 'sysObjBurg.m';
filenames{end+1} = 'HAL9000.m';
filenames{end+1} = 'spectrumAnalyzer.m';
filenames{end+1} = 'spectrumAnalyzer2.m';

%% Chapter 4.
filenames{end+1} = 'transferplot.m';
filenames{end+1} = 'noisyC.m';
filenames{end+1} = 'filterAudioFile.m';
filenames{end+1} = 'filterAudioFile_dsp.m';

%% Chapter 5.
filenames{end+1} = 'iirtypes.m';
filenames{end+1} = 'fir1demo.m';
filenames{end+1} = 'firlsdemo.m';
filenames{end+1} = 'firclsdemo.m';
filenames{end+1} = 'mindelay.m';
filenames{end+1} = 'mybandstop.m';
filenames{end+1} = 'filttimes.m';

%% Chapter 7.
filenames{end+1} = 'computePolyphase.m';
filenames{end+1} = 'fdesignDecim.m';
filenames{end+1} = 'sysObjDecim.m';
filenames{end+1} = 'fdesignInterp.m';
filenames{end+1} = 'multistageInterp.m';
filenames{end+1} = 'narrowbandLowpass.m';
filenames{end+1} = 'ifirDecim.m';

%% Chapter 8.
filenames{end+1} = 'adjustStepSize.m';
filenames{end+1} = 'adjustLength.m';
filenames{end+1} = 'nonStationary.m';
filenames{end+1} = 'ampWindowNLMS.m';
filenames{end+1} = 'noiseCancellation.m';

%% Exercises.
filenames{end+1} = 'hilo_simple.m';
filenames{end+1} = 'hilo.m';
filenames{end+1} = 'square10.m';
filenames{end+1} = 'square10_extra.m';
filenames{end+1} = 'sumSinesWithPhases.m';
filenames{end+1} = 'stackedSines.m';
filenames{end+1} = 'genChirp.m';
filenames{end+1} = 'logChirp.m';
filenames{end+1} = 'spectra.m';
% filenames{end+1} = 'hilopass.m';  FREQZ() causes hidden warning message.
filenames{end+1} = 'myfilt.m';
filenames{end+1} = 'resamp.m';
filenames{end+1} = 'messageFilt.m';
filenames{end+1} = 'messageFilt2.m';
filenames{end+1} = 'multistage.m';
filenames{end+1} = 'adaptNoiseCancel.m';

end



% %% Add these MATLAB commands into MATLAB command history.
% commands = {                                                                                        ...
%     'web_mbsfn',                                                                                    ...
%     'addpath(genpath(''c:\class\coursefiles\mlte''))',                                              ...
%     'plotdlrg(''1.4MHz'', ''FDD'', 0);',                                                            ...
%     'plotdlrg(''3MHz'', ''FDD'', 0);',                                                              ...
%     'plotrg(abs(A), [0 1]);',                                                                       ...
%     'plotrb(''3D'', 0, 1, 0, ''b'');',                                                              ...
%     'plotrb(''image'', 0, 1, 0, ''g'');',                                                           ...    
%     'searchpath(''.*'', ''MATLAB\\R2014b'', 1);',                                                   ...
%     'char(searchfile(''.'', ''*'', '''', ''*pss*'', ''''))',                                        ...
%     'searchtext(''files'', ''*'', '''', ''*.indd'', '''', ''virtual'', '''', 1)',                   ...
%     'winopen 36211-890-PhysicalChannelsAndModulation.pdf',                                          ...
%     'winopen 36212-880-MultiplexingAndChannelCoding.pdf',                                           ...
%     'winopen 36213-880-PhysicalLayerProcedures.pdf',                                                ...
%     'winopen mlte_00_toc_note.pdf',                                                                 ...
%     'winopen mlte_01_Introduction_note.pdf',                                                        ...
%     'winopen mlte_02_IntroductionToLTE_note.pdf',                                                   ...
%     'winopen mlte_03_IntroductionToOFDM_note.pdf',                                                  ...
%     'winopen mlte_04_3G_LTE_PhysicalResources_note.pdf',                                            ...
%     'winopen mlte_05_MIMO_note.pdf',                                                                ...
%     'winopen mlte_06_3G_LTE_DownlinkModulation_note.pdf',                                           ...
%     'winopen mlte_07_3G_LTE_Coding_note.pdf',                                                       ...
%     'winopen mlte_07_IntroductionToChannelCoding_note.pdf',                                         ...
%     'winopen mlte_08_3G_LTE_UplinkModulation_note.pdf',                                             ...
%     'winopen mlte_08_OFDMA_note.pdf',                                                               ...
%     'winopen mlte_09_3G_LTE_PhysicalLayerProcedures_note.pdf',                                      ...
%     'winopen mlte_10_3G_LTE_Release9_note.pdf',                                                     ...
%     'winopen mlte_11_3G_LTE_Advanced_note.pdf',                                                     ...
%     'winopen mlte_12_Conclusion_note.pdf',                                                          ...
%     '[1.4 3 5 10 15 20; 6 15 25 50 75 100]',                                                        ...
%     'enb = lteRMCDL(''R.4''); [txWaveform, txGrid, rmcCfgOut] = lteRMCDLTool(enb, [1 0 0 1]'');',   ...
%     'set(0, ''DefaultFigureWindowStyle'', ''docked'');',                                            ...
%     'set(0, ''DefaultFigureWindowStyle'', ''normal'');',                                            ...
%     'set(gca, ''position'', [0.0449, 0.0661, 0.93, 0.8589]);',                                      ...
%     'delete(findobj(''Tag'', ''Resource Block''))',                                                 ...
%     };
% for str = commands
%     com.mathworks.mlservices.MLCommandHistoryServices.add(str{1});
% end


% %% Find out the MLSG course top-level "files" directory.
% top = fileparts(fileparts(mfilename('fullpath')));


% % %% Test plotdlrg.m.
% % fprintf('Running %s ...\n', which('plotdlrg'));
% % lastwarn('');
% % NCellID = 0;
% % for bw = {'1.4MHz', '3MHz'}
% %     for duplexmode = {'FDD', 'TDD'}
% %         close all
% %         plotdlrg(bw{1}, duplexmode{1}, NCellID);
% %         close all
% %         if ~isempty(lastwarn)
% %             status = 0;
% %         end
% %     end
% % end
% 
% 
% % %% Test fftf.m.
% % fprintf('Running %s ...\n', which('fftf'));
% % if fftf('selftest') == 0
% %     status = 0;
% % end
% 
% 
% % %% Open all pdf files under folder "slides". Trainer machine only.
% % if strcmp(machineType, 'trainer')
% %     s = dir(fullfile(top, 'slides', '*.pdf'));
% %     for n = 1:length(s)
% %         winopen(s(n).name);
% %     end
% % end

