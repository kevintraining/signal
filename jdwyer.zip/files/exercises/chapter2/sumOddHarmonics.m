function [y,t] = sumOddHarmonics(f0, nHarmonics)
% y = sumOddHarminics(f0,n) generates a sum of n odd harmonics with the
% k-th harmonic having an amplitude of 1/k. The fundamental frequency is
% specified by f0. This approximates the Fourier series for a square wave.
oddNums = 1:2:(2*nHarmonics-1);
A = 1./oddNums;     % Amplitudes (row vector)
f = (f0.*oddNums)'; % Frequencies (remember to make them a column vector)
fs = 3*max(f);   % Choose a large enough sampling rate
t = 0:1/fs:3/f0; % Generate signal worth about three cycles
y = A*sin(2*pi*f*t);
plot(t,y);
title(['Square wave approximation with ',num2str(nHarmonics),' terms']);