%% 1: Load resamp.mat and Visualize spectrum
load resamp.mat
nfft = 1024;
Y = fft(y,nfft);
% Plot lower half of the FFT since signal is real
plot( (0:nfft/2)*fs/nfft, abs(Y(1:nfft/2+1)) )
title('Fs = 30 kHz, Fsin = 12 kHz')
xlabel('Frequency (Hz) \rightarrow');
ylabel('FFT Magnitude \rightarrow');

%% 2: Use upsample then downsample and visualize spectrum. See aliasing.
yUp = upsample(y,5);
yUpDown = downsample(yUp,6);
YUPD = fft(yUpDown,nfft);
figure(2)
plot( (0:nfft/2)*(fs*5/6)/nfft, abs(YUPD(1:nfft/2+1)) )
title('Aliasing')
xlabel('Frequency (Hz) \rightarrow');
ylabel('FFT Magnitude \rightarrow');

%% 3: Design anti-aliasing filter and apply the up/down-sampling
% Note: The upsampled signal has a sampling rate of 30*5 = 150 kHz
specs = fdesign.lowpass(12/75,12.5/75,1,60); % 'Fp,Fst,Ap,Ast'(default spec)
antialias = design(specs,'equiripple');
yUpFilt = filter(antialias,yUp);
yUpFiltDown = downsample(yUpFilt,6);
YUPFD = fft(yUpFiltDown,nfft);
figure(3)
plot( (0:nfft/2)*(fs*5/6)/nfft, abs(YUPFD(1:nfft/2+1)) )
title('With Antialias Filter');
xlabel('Frequency (Hz) \rightarrow');
ylabel('FFT Magnitude \rightarrow');

%% 4: Use interp then decimate and visualize spectrum
yInt = interp(y,5);
yIntDec = decimate(yInt,6);
YID = fft(yIntDec,nfft);
figure(4)
plot( (0:nfft/2)*(fs*5/6)/nfft,abs(YID(1:nfft/2+1)) )
title('Using ''interp'' and ''decimate'' commands');
xlabel('Frequency (Hz) \rightarrow');
ylabel('FFT Magnitude \rightarrow');

%% 5: Use resample and visualize spectrum
% Uses interpolation and decimation and 
% you can specify filter order
[yResamp,b] = resample(y,5,6);
YRS = fft(yResamp,nfft);
figure(5)
plot( (0:nfft/2)*(fs*5/6)/nfft,abs(YRS(1:nfft/2+1)) )
title('Using ''resample'' command');
xlabel('Frequency (Hz) \rightarrow');
ylabel('FFT Magnitude \rightarrow');
