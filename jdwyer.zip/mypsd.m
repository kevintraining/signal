function mypsd(x,fs)

[p, f] = pwelch(x,kaiser(8192,20),[],2^17,fs,'centered');

plot(f,10*log10(p));

end