%% Objective
%
% * In this exercse, you need to calculate and plot the magnitude spectra of two
%   complex tones.
%
% * Plot the 2 spectra in one figure.

%% Clear all variables.
clear
close all;
%% Create discrete-time signal x1[n] = complex tone at 10 Hz. Fs = 100 Hz.
Fs = 100;
t  = (0:3) / Fs;
x1  = exp(1i * 2 * pi * 10 * t);

%% Create discrete-time signal x2[n] = complex tone at -10 Hz. Fs = 100 Hz.
% TODO: Add your code here.
x2 = exp(1i * 2 * pi * -10 * t);
%% Calculate FFT of x1[n].
% TODO: Add your code here.
X1 = fft(x1,2^17);
%% Calculate FFT of x2[n].
% TODO: Add your code here.
X2 = fft(x2,2^17);
%% Plot FFT of x1[n].
% TODO: Add your code here.
f1 = (-length(X1)/2:(length(X1)/2)-1)*Fs/length(X1);
figure;
plot(f1,abs(fftshift(X1)))
%% Plot FFT of x2[n].
% TODO: Add your code here.
f2 = (-length(X2)/2:(length(X2)/2)-1)*Fs/length(X2);
hold on
plot(f2,abs(fftshift(X2)),'r')
