%% Clean up.
clear

%% Create a complex tone x[n].
Fs = 100;
t  = (0:100) / Fs;
x  = exp(1i * 2 * pi * 10 * t);

%% Calculate FFT.
X = fftshift(fft(x, 2^17));
f = fftf(length(X), Fs);

%% Plot FFT.
figure(1)
clf
X = X / max(abs(X));
plot(f, 20*log10(abs(X)))
xlabel('Frequency (Hz)')
ylabel('|X(f)|')
title('Magnitude Spectrum')

%% Apply Windowing.
x1 = x .* kaiser(length(x), 20).';

%% Calculate FFT.
X1 = fftshift(fft(x1, 2^17));
f1 = fftf(length(X1), Fs);
hold on
X1 = X1 / max(abs(X1));
plot(f1, 20*log10(abs(X1)))

