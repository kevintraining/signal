%% Clear all variables
clear

%% No Windowing. See two tones at 100 Hz and 101 Hz. Cannot see tone at 110 Hz.
Fs = 1000;
t  = (0 : 4095) / Fs;
x  = sin(2*pi*100*t) + sin(2*pi*101*t) + 0.001*sin(2*pi*110*t);
X  = fftshift(fft(x, 2^17));
figure(1)
clf
plot(fftf(length(X), Fs), 20*log10(abs(X)))

%% Apply Kaiser window. See the tone at 110 Hz. Something around 100 Hz.
x1 = x .* kaiser(length(x), 20).';
X1 = fftshift(fft(x1, 2^17));
figure(2)
clf
plot(fftf(length(X1), Fs), 20*log10(abs(X1)))

%% See all 3 tones
%
% * Increase number of samples.
%
% * Apply windowing.
%
Fs = 1000;
t  = (0 : 131071) / Fs;
x2 = sin(2*pi*100*t) + sin(2*pi*101*t) + 0.001*sin(2*pi*110*t);
x2 = x2 .* kaiser(length(x2), 20).';
X2 = fftshift(fft(x2, 2^20));   % Million Point FFT
figure(3)
clf
plot(fftf(length(X2), Fs), 20*log10(abs(X2)))

