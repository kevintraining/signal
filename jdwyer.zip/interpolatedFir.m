% ------------------------------------------------------------------------------
%               Actual Location of Transition Region Does Not Matter
% ------------------------------------------------------------------------------

%% Start from scratch.
clear
fs = 100;

%% Lowpass filter. Passband frequency = 30 Hz. 61 taps.
b1 = firpm(60, [0 30 35 50]/(fs/2), [1 1 0 0], [1 80]);
f  = fvtool(b1, 1, 'Fs', fs);

%% Lowpass filter. Passband frequency = 20 Hz. 61 taps.
b2 = firpm(60, [0 20 25 50]/(fs/2), [1 1 0 0], [1 80]);
f.addfilter(b2, 1, 'Fs', fs);

%% Lowpass filter. Passband frequency = 10 Hz. 61 taps.
b3 = firpm(60, [0 10 15 50]/(fs/2), [1 1 0 0], [1 80]);
f.addfilter(b3, 1, 'Fs', fs);


% ------------------------------------------------------------------------------
%                       Transition Bandwidth Matters
% ------------------------------------------------------------------------------

%% Start from scratch.
clear
fs = 100;

%% Lowpass filter. Transition Bandwidth = 10 Hz. 31 taps.
b1 = firpm(30, [0 10 20 50]/(fs/2), [1 1 0 0], [1 80]);
f  = fvtool(b1, 1, 'Fs', fs);

%% Lowpass filter. Transition Bandwidth = 5 Hz. 31 taps.
b2 = firpm(30, [0 10 15 50]/(fs/2), [1 1 0 0], [1 80]);
f.addfilter(b2, 1, 'Fs', fs);

%% Lowpass filter. Transition Bandwidth = 5 Hz. 61 taps.
b3 = firpm(60, [0 10 15 50]/(fs/2), [1 1 0 0], [1 80]);
f.addfilter(b3, 1, 'Fs', fs);


% ------------------------------------------------------------------------------
%                           Interplated FIR Filter
% ------------------------------------------------------------------------------

%% Start from scratch.
clear
fs = 100;

%% Lowpass filter. Transition bandwith = 5 Hz. Filter length = 61 taps.
b1 = firpm(60, [0 15 20 50]/(fs/2), [1 1 0 0], [1 80]);
f  = fvtool(b1, 1, 'Fs', fs);

%% Lowpass filter. Transition bandwith = 10 Hz. Filter length = 31 taps.
b2 = firpm(30, [0 30 40 50]/(fs/2), [1 1 0 0], [1 80]);
f.addfilter(b2, 1, 'Fs', fs);

%% Trick: Insert zeros
b3 = upsample(b2, 2);
f.addfilter(b3, 1, 'Fs', fs);

%% Image Rejection Filter.
b4 = firpm(20, [0 15 30 50]/(fs/2), [1 1 0 0], [1 80]);
f.addfilter(b4, 1, 'Fs', fs);

%% Final Comparison.
f = fvtool(b1, 1, 'Fs', fs);
f.addfilter(conv(b3, b4), 1, 'Fs', fs);



