function uploadclassfiles(zipfilename)

% Example: uploadclassfiles('kevin.zip')

cd c:\class
githubget githubsvn.p
zip(fullfile('c:', zipfilename), 'c:\class\*');
githubsvn co https://github.com/kevintraining/signal.git c:\signal
movefile(fullfile('c:', zipfilename), 'c:\signal\trunk')
githubsvn(['add ', fullfile('c:\signal\trunk\', zipfilename)]);
githubsvn(['ci ', fullfile('c:\signal\trunk\', zipfilename), ' -m "Upload"']);

end

