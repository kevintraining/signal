function [y,t] = sumHarmonics(ff,numOddHarmonics)

oddNums = 1:2:(2*numOddHarmonics-1);
A       = 1./oddNums;

f       = (ff * oddNums).';
fs      = 5000;

t = 0:1/fs:99/fs;
y = 0;
for i = 1:length(f)
    y = y + A(i)*sin(2*pi*f(i).*t);
end



end