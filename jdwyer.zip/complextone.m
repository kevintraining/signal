clear


%x[n]
Fs = 100;
t = (0:3)/Fs;

x = exp(1i * 2*pi*10*t);

X = fft(x,2^17);

f = (-length(X)/2:(length(X)/2)-1)*Fs/length(X);
fk = fftf(length(X),Fs);

plot(f,abs(fftshift(X)));