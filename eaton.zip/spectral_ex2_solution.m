%% Clear all variables.
clear

%% Create square wave approximation as sum of odd harmonics.
nHarmonics = 10;
f0         = 10;
oddNums = 1:2:(2*nHarmonics-1);
A = 1./oddNums;     % Amplitudes (row vector)
f = (f0.*oddNums)'; % Frequencies (remember to make them a column vector)
Fs = 3*max(f);   % Choose a large enough sampling rate
t = 0:1/Fs:10/f0; % Generate signal worth about five cycles
x = A*sin(2*pi*f*t);

%% Plot x[n].
figure(1)
clf
plot(t,x);
title(['Square wave approximation with ',num2str(nHarmonics),' terms']);

%% Calculate FFT.
X = fftshift(fft(x, 2^17));
f = fftf(length(X), Fs);

%% Plot FFT.
figure(2)
clf
plot(f, abs(X))
xlabel('Frequency (Hz)')
ylabel('|X(f)|')
title('Magnitude Spectrum')