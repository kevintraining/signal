function continuous

figure
t  = 0 : 1/1000 : 1;
xt = cos(2*pi*2.3*t) + cos(2*pi*3.4*t);     % Simulate Continuous Time Signal
plot(t, xt, 'LineWidth', 4)
hold on
t  = 0 : 1/10 : 1;
xn = cos(2*pi*2.3*t) + cos(2*pi*3.4*t);     % Discrete Time Signal
plot(t, xn, 'o', 'MarkerFaceColor', 'r', 'MarkerSize', 10)
xlabel('Time (Seconds)')
ylabel('Amplitude')
title('Uniform Sampling. Sampling Rate (Fs) = 0.1 seconds.',    ...
      'FontSize',   20,                                         ...
      'FontWeight', 'bold');
legend({'Continuous-Time Signal x(t)', ...
        'Discrete-Time Signal x[n]'}, 'FontSize', 20)

end
