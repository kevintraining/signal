fs = 1000;
ts = 0:1/fs:2;
f = 250 + 240*sin(2*pi*ts);
x = 0.1*sin(2*pi*f.*ts);
strips(x,0.25,fs)
% Play the signal without any modification
sound(x,fs)
%% Play the signal scaled to �1
pause(1);
soundsc(x,fs)