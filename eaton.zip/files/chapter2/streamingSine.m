%% Generate and process a sequence of samples of a sine wave with a
% sampling rate of 1000 Hz, frequency of 100 Hz and amplitude of 0.8.
%
A = 0.8;
f = 100;
fs = 1000;
framesize = 796; % This is the number of samples to be generated at a time.
%% Create the System object with default properties
H = dsp.SineWave;
% Set up property values as desired
H.Amplitude = A;
H.Frequency = f;
H.SampleRate = fs;
H.SamplesPerFrame = framesize;
%% Generate and process the samples in a loop
s = [];
for n = 1:100
    % Generate the samples by calling the step() function on H.
    x = step(H); % "x" contains "framesize" samples
    % Here you will process the samples with your algorithm.
    % In this example, you will just collect the samples in an array
    % for plotting
    s = [s;x]; %#ok<*AGROW>
end
plot(s(770:830),'-o');
title('Phase continuity is maintained by the System object');
release(H);
%% Do the same thing using sin function
p = [];
k = 0:framesize-1;
for n = 1:100
    x = A*sin(2*pi*k*f/fs);
    p = [p,x];
end
figure; plot(p(770:830),'-o');
title('Notice the phase discontinuity');