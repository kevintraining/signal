% Observe the effect of varying LMS filter step size:

load adaptAnalysis
% adaptAnalysis.mat contains backup signals x and d (constructed in the
% same manner as on page 8)

% Create new LMS filter
HA2 = dsp.LMSFilter;

% Set step size to be input to step() method
HA2.StepSizeSource = 'Input port';

% Set filter to take filter reset flag as input
HA2.WeightsResetInputPort = true;

% Effect of step size:
figure
mu = [0.001 0.01 0.1 1 10 50];% vector of step sizes

for i = 1:length(mu)
    % Run LMS algorithm on entire inputs with varying step size.  Time the
    % duration of algorithm in each iteration
    tic
    [y,e,w] = step(HA2,x,d,mu(i),true);
    toc
    % Note: run time is nearly constant - step size does not affect the
    % number of computations
    
    % Plot smoothed squared error on semilog axes to analyze convergence
    % behavior
    semilogy(filter(ones(500,1)/500,1,e.^2))
    
    % Plot all iterations on same axes
    hold all
end

legend(num2str(mu'),'Location','Best')
xlabel('Sample Number')
ylabel('Filtered Square Error')
title('LMS Filter Convergence with Length = 32 and Varying Step Size')
ylim([1e-5 1e0])
grid on
hold off

clear HA2