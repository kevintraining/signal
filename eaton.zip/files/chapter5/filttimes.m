%% FILTTIMES Demonstrates the critical filter length beyond which FFTFILT out-performs FILTER.

% NOTE: The FFT used in MATLAB (FFTW) is a highly 
% optimized algorithm that uses many tricks for 
% efficiency. It may not be representative of the 
% performance you can expect on embedded hardware.

% Random signal:
x = rand(1,1e5);

% We will filter x with random FIR filters of 
% increasing length, using both FILTER and FFTFILT.
L1 = 5; % Starting filter length
L2 = 1e3; % Ending filter length
dL = 5e1; % Step size between lengths
n = round((L2-L1)/dL); % Number of filter lengths considered

FILTERTIMES = zeros(1,n);
FFTFILTTIMES = zeros(1,n);

m = 1; % Filter time being computed, 1 <= m <= n.
for L = L1:dL:L2
    b = rand(1,L); % Random FIR filter of length L
    tic; filter(b,1,x); t1 = toc;
    tic; fftfilt(b,x); t2 = toc;
    FILTERTIMES(m) = t1;
    FFTFILTTIMES(m) = t2;
    m = m+1;
end

L = L1:dL:L2; 
plot(L,FILTERTIMES,'b-o',L,FFTFILTTIMES,'rx-')
xlabel('Filter Length')
ylabel('Time to Filter Signal (secs)')
title('Fixed Signal Length')
legend('Using FILTER', 'Using FFTFILT') 