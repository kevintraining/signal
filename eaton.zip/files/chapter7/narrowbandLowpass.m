%% Try the Single-Rate/Single-Stage Equiripple Design
Fpass = 0.1;   % Passband edge
Fstop = 0.11;  % Stopband edge
Rpass = 0.01;  % Passband ripple, 0.01 dB peak to peak
Rstop = 80; % Stopband attenuation, 60 dB minimum attenuation

% Construct a filter specification object
filtSpec = fdesign.lowpass(Fpass,Fstop,Rpass,Rstop);
% Design single rate filter
hLowFilt = design(filtSpec,'equiripple');
% Display cost
cost_singleStage = cost(hLowFilt) %#ok<*NOPTS>

%% Reduce Computational Cost Using IFIR Design
hLowFilt_ifir = design(filtSpec,'ifir');
% Display cost
cost_IFIR = cost(hLowFilt_ifir)

%% Reduce Computational Cost Using Mulitrate/Multistage Design
hLowFilt_multi = design(filtSpec,'multistage','SystemObject',true);
% Display cost
cost_multi = cost(hLowFilt_multi)

%% Compare the Responses
hfvt = fvtool(hLowFilt,hLowFilt_ifir,hLowFilt_multi);
legend(hfvt,'Equiripple design','IFIR design','Multirate/multistage design')
% Once FVTool opens, check the group delays and the step responses

%% Further Performance Comparison
% Create sum of two tones
n = 0:1799;
x = sin(0.05*pi*n') + 2*sin(0.15*pi*n');
% Filter the sum of tones with each filter
y = filter(hLowFilt,x); % use single rate filter
y_ifir = filter(hLowFilt_ifir,x); % use IFIR design
% Use multistage design. Note that we need to explicitly call the STEP method
% for each stage to apply filtering. This is because a STEP method is not
% supported for object dsp.FilterCascade.
tmp     = step(hLowFilt_multi.Stage1,x);
tmp     = step(hLowFilt_multi.Stage2,tmp);
tmp     = step(hLowFilt_multi.Stage3,tmp);
tmp     = step(hLowFilt_multi.Stage4,tmp);
tmp     = step(hLowFilt_multi.Stage5,tmp);
y_multi = step(hLowFilt_multi.Stage6,tmp);

% Observe the PSD of each output in comparison to the input PSD
[Pxx,w] = periodogram(x);
Pyy = periodogram(y);
Pyy_ifir = periodogram(y_ifir);
Pyy_multi = periodogram(y_multi);
plot(w/pi,10*log10([Pxx, Pyy, Pyy_ifir, Pyy_multi]) );
xlabel('Normalized Frequency (x\pi rad/sample)');
ylabel('Power density (dB/rad/sample)');
legend('Input signal PSD','Equiripple output PSD','IFIR output PSD',...
    'Multirate/multistage output PSD')
axis([0 1 -50 30])
grid on
