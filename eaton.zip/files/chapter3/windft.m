% WINDFT Shows the effects on the DFT of truncating a signal and then windowing.

% Truncated 5Hz sine wave
fs = 100;               % Sampling rate
t = 0:1/fs:1;           % Time base
y = sin(2*pi*5*t);      % 5 Hz signal

% Plot truncated signal
figure
subplot(2,1,1)
plot(t,y,'b')
axis([0 1 -1 1])
title('Truncated Signal')

% Take DFT
Y = fft(y, 512);

% Plot first half of frequencies
% (second half is redundant)
f = 100*(0:256)/512;
subplot(2,1,2)
plot(f, abs(Y(1:257)), 'b')
axis([0 10 0 50])
title('DFT of Truncated Signal')
ylabel('Magnitude')

% Multiply truncated signal by Gaussian window
w = gausswin(length(y));
wy = w'.*y;

% Plot truncated, windowed signal
figure
subplot(2,1,1)
plot(t,wy,'r')
axis([0 1 -1 1])
title('Truncated, Windowed Signal')

% Take DTFT
wY = fft(wy, 512);

% Plot first half of frequencies
% (second half is redundant)
wf = 100*(0:256)/512;
subplot(2,1,2)
plot(wf, abs(wY(1:257)), 'r')
axis([0 10 0 25])
title('DFT of Truncated, Windowed Signal')
ylabel('Magnitude')