%% Design arbitrary response FIR filter
%  ====================================
% Use fdesign.arbmag to create a filter specification object
doc fdesign.arbmag

%% There are several specification options for this command. The easiest
%  is when you specify the filter order yourself and see the design you got
%  was acceptable or not.
%
% There are four bands in your filter - two pass bands and two stop bands
B = 4;
% Set filter magnitude specification. Note that repeated frequencis are not
% allowed in the frequency vector (no zero-width transition bands).
fs = 8000;
fNyq = fs/2;
f = [0, 150, 160, 1750, 1800, 2200, 2250, fNyq]/fNyq;
m = [1, 1, 0, 0, 1, 1, 0, 0]; % Replace the zeros by a small number, e.g.
                              % 1e-05, to see the specification mask on a
                              % dB plot.

%% Set filter order to 150 and construct a filter specification object
%  with specification string 'N,B,F,A', where you only specify the N and
%  the B to start with. This allows to see how it expects you to specify
%  the other parameters (F and A).
N = 150;
d = fdesign.arbmag('N,B,F,A',N,B) %#ok<*NOPTS>
% Execute the above statement and look at the MATLAB Command Window to see
% the parameter names and their sequence. It seems it wants all the band
% frequencies and amplitudes specified separately.

%% Break up the specification vectors into bands.
F1 = f(1:2);
A1 = m(1:2); % Band 1
F2 = f(3:4);
A2 = m(3:4); % Band 2
F3 = f(5:6);
A3 = m(5:6); % Band 3
F4 = f(7:8);
A4 = m(7:8); % Band 4

%% Create filter specification object and find design methods
d = fdesign.arbmag('N,B,F,A',N,B,F1,A1,F2,A2,F3,A3,F4,A4);
% Find out what design methods are available for designing an FIR filter
firMethods = designmethods(d,'fir')

%% There are two FIR design methods available. You can try both and see
%  which one is better.
hAllFIR = design(d,'allfir'); % This will design all FIR designs possible
% Plot the frequency responses
fvt = fvtool(hAllFIR);
legend(fvt,firMethods{:});

%% Clearly firls design produced a better filter. So, choose that one.
hMyFIR = hAllFIR(2);
[h,w] = freqz(hMyFIR);
plot(f,m,'r--',w/pi,abs(h),'b-','LineWidth',2);
legend('Magnitude specification','Filter response');

%% Load the communication signal and plot the spectrum
load noisyX
figure;
pwelch(noisyX,[],[],[],fs);
title('PSD of the communication signal');
% soundsc(noisyX);

%% Filter the noisy signal and look at the spectrum
y = filter(hMyFIR,noisyX);
figure;
pwelch(y,[],[],[],fs);
title('PSD of the message signal');

%% Plot the communication signal and the message signal (after filtering)
figure;
plot(noisyX);
hold on;
plot(y,'r','LineWidth',2);
xlim([0 200]); % Zoom into the first 200 samples
legend('Communication signal','Message signal');
% soundsc(y);