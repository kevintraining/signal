%% Generate sum of sinusoids with zero initial phases
A = [1, 1/3, 1/5, 1/7, 1/9]; % Amplitudes
f = [100; 300; 500; 700; 900]; % Frequencies
fs = 8000; % Sampling rate
t = 0:1/fs:0.03;
x = A*sin(2*pi*f*t);
plot(t,x); hold on;
%% Add sinusoids with specified initial phases
phi = [0; pi/4; pi/4; pi/8; pi]; % Note that the phases make a column vector
xphi = A*sin(2*pi*f*t + repmat(phi,size(t)));
plot(t,xphi,'r');
legend('Zero initial phases','Specified initial phases');