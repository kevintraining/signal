function [y,t] = mySumHarmonics (f0, nHarmonics)

oddNums = 1:2:(2*nHarmonics-1);
A = 1./oddNums;
f = (f0*oddNums).';
fs = 3*max(f);

t = 0:1/fs:3/f0;
out = 0;
for ii = 1:length(f)
    out = out + A(ii)*sin(2*pi*f(ii)*t);
end

figure;
plot(t,out);

end