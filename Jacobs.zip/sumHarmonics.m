function [y,t] = sumHarmonics(f0, nHarmonics, nPeaks, voices)
%SUMHARMONICS Summary of this function goes here
%   Detailed explanation goes here
if(nargin<3)
    nPeaks = 3;
end

oddNums = 1:1:(2*nHarmonics - 1);
A = 1 ./ oddNums;
f = (f0 * oddNums).';

fs = 3*max(f);

%ToDo
t  = 0:1/fs:nPeaks/f0;

x = zeros(1, length(t));

for voice = 1 : voices
    scale = ((voice-0.5)/voices) - (1/2);
    
    for k = 1:length(A)
        x = x + A(k)*sin(2*pi*f(k)*t + (scale*(pi/2)));
    end
    
end
y = x;
a =[1,2];
b = [1,0,0.2];

y = filter(b,a,y);
soundsc(y);
figure;
plot(t,y);

end

