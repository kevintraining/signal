%% Clear all variables.
clear

%% Create noisy signal.
rng(123, 'twister');
Fs = 1000;
t  = (0 : 1e6) / Fs; 
x  = cos(2*pi*200*t) + cos(2*pi*210*t) + 0.5*randn(size(t));

%% Use pwelch to calculate PSD.
[P, f] = pwelch(x, kaiser(8192, 20), [], 2^17, Fs, 'centered');
figure(1)
clf
plot(f, 10*log10(P))
















