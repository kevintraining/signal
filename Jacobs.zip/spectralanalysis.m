% ------------------------------------------------------------------------------
%                       What is Spectral Analysis?
% ------------------------------------------------------------------------------

%% Objective
%
% * Given signal x[n], find out how many tones and the magnitudes of each tone.

%% Algorithm
%
% * Step 1: Perform FFT (with zero-padding) of x[n].
%
% * Step 2: Locate peaks in the magnitude spectrum:
%               (a) Number of peaks = number of tones.
%               (b) Height of each peak = magnitude of each tone.

% --------------------------
%   Single Complex Tone
% --------------------------

%% Start from scratch.
clear

%% Create discrete-time signal x[n].
Fs = 100;
t  = (0:3) / Fs;
x  = exp(1i * 2 * pi * 10 * t);

%% Calculate FFT.
X = fftshift(fft(x, 2^17));
f = fftf(length(X), Fs);

%% Plot FFT.
figure(1)
clf
plot(f, abs(X))
xlabel('Frequency (Hz)')
ylabel('|X(f)|')
title('Magnitude Spectrum')

% ----------------------------------------------------
%   Single Real Tone (i.e. Sum of Two Complex Tones)
% ----------------------------------------------------

%% Start from scratch.
clear

%% Create discrete-time signal x[n].
Fs = 100;
t  = (0:3) / Fs;
x  = cos(2 * pi * 10 * t);

%% Calculate FFT.
X = fftshift(fft(x, 2^17));
f = fftf(length(X), Fs);

%% Plot FFT.
figure(1)
clf
plot(f, abs(X))
xlabel('Frequency (Hz)')
ylabel('|X(f)|')
title('Magnitude Spectrum')

% --------------------------------------------
%   Sum of Two Real Tones (Equal Amplitudes)
% --------------------------------------------

%% Start from scratch.
clear

%% Create discrete-time signal x[n].
Fs = 100;
t  = (0:30) / Fs;
x  = cos(2 * pi * 10 * t) + cos(2 * pi * 15 * t);

%% Calculate FFT.
X = fftshift(fft(x, 2^17));
f = fftf(length(X), Fs);

%% Plot FFT.
figure(1)
clf
plot(f, abs(X))
xlabel('Frequency (Hz)')
ylabel('|X(f)|')
title('Magnitude Spectrum')

% ---------------------------------------------------
%   Sum of Two Real Tones (One large and one small)
% ---------------------------------------------------

%% Start from scratch.
clear

%% Create discrete-time signal x[n].
Fs = 100;
t  = (0:300) / Fs;
x  = cos(2 * pi * 10 * t) + 0.001*cos(2 * pi * 30 * t);

%% Calculate FFT.
X = fftshift(fft(x, 2^17));
f = fftf(length(X), Fs);

%% Plot FFT.
figure(1)
clf
plot(f, 20*log10(abs(X)))   % Must use dB. See large and small numbers.
xlabel('Frequency (Hz)')
ylabel('|X(f)| in dB')
title('Magnitude Spectrum')

