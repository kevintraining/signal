%% Clear all variables.
clear

%% Create single tone signal.
t = (0 : 1e5) / 100;
x = sin(2*pi*10*t);
figure(1)
clf
mypsd(x, 100);

% %% Lowpass filter signal x.
% %TODO
% fvtool(h, 'Fs', 100)
% x = filter(h, 1, x);
% figure(3)
% clf
% mypsd(x, 100);

%% Keep every other sample.
% TODO
figure(2)
clf
mypsd(y, 50);



