function mypsd(x,Fs)

[p,f] = pwelch(x, kaiser(8192, 20), [], 2^17, Fs, 'centered');
figure
plot(f,10*log10(p));

end