%% Generate a 2Hz square wave with 10% duty cycle sampled at 8000Hz for a
%  duration of 2 seconds.
fs = 8000;
t = 0:1/fs:2;
x = square(2*pi*2*t,10);
plot(t,x,'LineWidth',2);
axis([-0.1 2.1 -1.1 1.1]); % Set plot axis limits for better display