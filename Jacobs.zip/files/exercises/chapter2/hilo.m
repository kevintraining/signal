%% Generate a number of sine waves and add them

fs = 2000;				% Sampling rate
t = 0:1/fs:3;           % Time base
A = [10, 1];            % Amplitudes (row vector)	
f = [50; 950];          % Frequencies (column vector)
x = A*sin(2*pi*f*t);	% Signal
plot(t,x)
title('High and Low')
soundsc(x,fs)