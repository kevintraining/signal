%% Generate a long chirp signal in a for loop
%=======================================================================
% The starting frequency of the chirp should be 10 Hz, the end frequency is
% 100 Hz. The frequency sweep should be linear and bidirectional with a
% target time and sweep time of 1 second. The sampling rate is 1000 Hz and
% the number of samples per frame is 1000. The for loop should be run 100
% times.
% Plot the complete signal at the end. Restrict the view to 1 frame
% of samples using the axis command. Use the zoom and pan buttons to
% confirm that phase continuity is maintained across frame boundaries.
%
hChirp = dsp.Chirp(...
    'SweepDirection','Bidirectional',...
    'InitialFrequency',10,...
    'TargetFrequency',100,...
    'SampleRate',2000,...
    'SamplesPerFrame',100) %#ok<*NOPTS>
%% Set up a signal sink System object
hSigLog = dsp.SignalSink
%% Run the loop and process
for k = 1:100
    x = step(hChirp); % Generate a frame of chirp signal
    step(hSigLog, x); % Save the signal in a signal sink buffer
end
sig = hSigLog.Buffer;
plot(sig); grid on;
axis([0 1000 -1.5 1.5]);