%% Make it a cell so that we can make edits and run it 
%  without saving the file.
Fs = 8000;
n = 0:63; % Data length (increase it slowly and see what happens)
x1 = sin(2*pi*200/Fs*n);
x2 = sin(2*pi*250/Fs*n);
y = x1 + x2+ 1e-6*randn(1,length(n));
[Pxx_periodo] = periodogram(y,[],'onesided',1024,Fs);
[Pxx_burg,f] = pburg(y,8,1024,Fs);
Periodo_dB = 10*log10(Pxx_periodo);
Burg_dB = 10*log10(Pxx_burg);
plot(f,Periodo_dB,f,Burg_dB); grid on;
legend('Periodogram','Burg');
title('Comparison of PSD estimates using Periodogram and Burg method');
xlabel('Frequency (Hz) -->');
ylabel('Power (dB) -->');