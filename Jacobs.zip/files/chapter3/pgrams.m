%% PGRAMS Basic spectral analysis with the FFT.

%% Data.
Fs = 100; % Sample frequency
t = 0:1/Fs:10; % Time range [0,10]
y = sin(2*pi*15*t) + sin(2*pi*30*t); % Data with two component frequencies

%% Compute the DFT and the power.
n = length(y); % Window length
Y = fft(y); % DFT of signal
f = (0:n-1)*(Fs/n); % Frequency range
P = Y.*conj(Y)/n; % Power of the DFT

%% Plot the periodogram.
figure
plot(f,P)
title('{\bf Periodogram}')

%% Center the frequency range at zero.
f0 = (-n/2:n/2-1)*(Fs/n); % zero-centered frequency range
P0 = fftshift(P); % Rearrange periodogram to be zero-centered
%% Plot the zero-centered periodogram.
figure
plot(f0,P0)
title('{\bf Zero-Centered Periodogram}')