%% processPulsedSignal Loads and process signal from generatePulsedSignal
% The transmission effects of delay and noise are simulated. Delay would be
% important in any time critical applications, angle of arrival
% measurements, radar range determination. Noise would affect the ability
% to measure this delay by looking directly at the peaks in the signal. We
% therefore use correlation to act as a matched filter to reduce noise and
% to provide a direct measure of delay.

%% Load data
% Data loads as a structure. Need to access each field.
sigData = load('myBeepSig');


%% Simulate delay
% Delay by 23 samples (at the baseband sample rate).
delayAmt = 23;
sigDelayed = 0.7*[zeros(delayAmt*sigData.fs_mod/sigData.fs,1); sigData.sigMod];

%% Add Gaussian noise with a standard deviation of 0.1
rng('default');
noise = 0.1*randn(size(sigDelayed));
sigNoisy = sigDelayed + noise;

%% Demodulate
% Demodulate the signal. This gives an oversampled output, hence decimate.
sigDemod = demod(sigNoisy,sigData.fc,sigData.fs_mod,sigData.modType);
sigDec = decimate(sigDemod,sigData.fs_mod/sigData.fs,'fir');

%% Measure delay and RMS.
% Delay is measured via cross-correlation.
[c,lags] = xcorr(sigDec,sigData.sigPulse);
[~,delayInd] = max(c);
delay = lags(delayInd)

% Measure the RMS values.
transmitRms = sqrt(mean(sigData.sigPulse(1:100).^2))
receiveRms = sqrt(mean(sigDec(delay+1:delay+100).^2))