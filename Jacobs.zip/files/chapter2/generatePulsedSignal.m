%% generatePulsedSignal Generate then modulate a pulsed signal
% The example will generate an audio beep signal that can be transmitted in
% the AM frequency band.
%
% This could be used e.g for the talking clock "at the fourth beep the time
% will be..."
%
% Generate sinusoid at an audio frequency. Follow this by generating a pulsed
% waveform. The multiplication of these gives a beeping tone. Reference to
% other signal generation options is possible as well.
% Interpolate the beep signal to increase the sample before modulation for
% transmission.


%% Generate sinusoid
% Using an audio frequency sample rate of 4kHz, generate a tone at 1kHz.
fs = 4e3;
t = (0:1/fs:1)';
f0 = 1e3;
signal_1kHz = cos(2*pi*f0*t);

%% Generate pulses
% Pulses are generated as a square wave with a 30% duty cycle.
% Application of the pulse modulation to the tone produces a beeping sound.
% Other audio effects could be achieved with e.g. sawtooth.

% pulses = bias + 0.5*squarewave
pulses = 0.5 + 0.5*square(2*pi*4*t,30);

% Apply pulse
sigPulse = signal_1kHz .* pulses;

%% Visualise and listen to signals
% For axis units, assume the signal is in volts.
figure; plot(t,[signal_1kHz, sigPulse])
hold all
stairs(t,pulses)
axis([0 1 -1.5 1.5]);
xlabel('Time (s)');
ylabel('Voltage (V)');
legend('Tone at 1kHz', 'Pulsed tone','Pulse waveform')
sound(sigPulse,fs);

%% Resample
% Interpolate to go from 4 kHz (audio) to 2 MHz sample rate for AM band
% carrier at 600 kHz. This must be completed prior to modulation.
fs_mod = 2e6;
sigInterp = interp(sigPulse,fs_mod/fs);

%% Modulation
% Using an amplitude modulation here for simplicity. For radio, AM tends to
% be used at the medium wave band and phase or frequency modulation at HF.
modType = 'amdsb-sc';
fc = 600e3;
sigMod = modulate(sigInterp,fc,fs_mod,modType);

%% Save signal
% We may want to save the pure transmitted signal here. Following this we
% would simulate transmission effects and processing after receiving the
% signal. However, the pure tone is useful in some of that processing. It
% also enables us to experiment with different transmission effects and
% different processing schemes without regenerating the signal.
save('myBeepSig','sigMod','fs','fs_mod','modType','fc','sigPulse','pulses','f0');
