clear
load noiseCancel

% Contents of noiseCancel.mat:
%  Three 10-second signals:
%  - debussy (clean information signal)
%  - noise (broadband noisy signal)
%  - talking (broadband and narrowband noisy signal)
%  Two path filters (dsp.DigitalFilter System Objects):
%  -H_lowpass
%  -H_bandpass
%  Audio Player (dsp.AudioPlayer System Object)
%  -HPlayer
%  Sampling Frequency of Signals (8 kHz)
%  -Fs

%% Play clean signal
soundsc(debussy,Fs)
%% Play broadband noise
soundsc(noise,Fs)
%% Generate dsp.SignalSource objects for signals, with frame size 1000
H_debussy = dsp.SignalSource('Signal',debussy,'SamplesPerFrame',1000);
H_noise = dsp.SignalSource('Signal',noise,'SamplesPerFrame',1000);
H_talking = dsp.SignalSource('Signal',talking,'SamplesPerFrame',1000);


%% Create new Adaptive Filter System Object
HA = dsp.LMSFilter('Length',50, ...
    'StepSizeSource','Input Port','WeightsResetInputPort',true);

%% Create signal logger to record filter weights after each frame for analysis
H_wts_buf = dsp.SignalSink;

%% Baseline Case
% Estimate the weights of a lowpass filter in the path of a stationary
% broadband noise source to cancel out the filtered noise and isolate the
% clean signal

% Release all relevant System Objects to ensure FIR filter weights and
% filter states are set to zero, buffers are empty, and signals are at
% their beginning
releaseAll(HPlayer,H_bandpass,H_debussy,H_lowpass,H_noise,H_talking,H_wts_buf,HA)

HA.Length = 50;

mu = 0.0002;

% Set H_path to point to the lowpass filter System Object
H_path = H_lowpass;

% Set H_input to point to the white noise signal System Object
H_input = H_noise;

while ~isDone(H_debussy)% Keep iterating until clean signal has no more data
    % Get one frame of input noise data (in this case we cannot inline the
    % step(dsp.SignalSource) method because we need that data again to
    % construct d)
    x = step(H_input);
    
    % Construct d by running the path filter on x and adding one frame of
    % clean signal
    d = step(H_path,x)+step(H_debussy);
    
    % Run the LMS filter algorithm for one frame of inputs
    [y,e,w] = step(HA,x,d,mu,false);
    
    % Play one frame of the error signal (estimate of clean signal) with
    % audio device
    step(HPlayer,e)
    
    % Log the estimated FIR filter weights in the buffer System Object
    step(H_wts_buf,w')
end

% Calculate time vector for start of each signal frame
t_frame = (0:(size(H_wts_buf.Buffer,1)-1))*H_debussy.SamplesPerFrame/Fs;

% Visualize estimated FIR filter response vs. time using a surface plot
if isequal(H_path,H_lowpass)
    pathStr = 'Lowpass Filter';
elseif isequal(H_path,H_bandpass)
    pathStr = 'Bandpass Filter';
else
    pathStr = 'Unknown Filter';
end

if isequal(H_input,H_noise)
    inputStr = 'Stationary Broadband Noise';
elseif isequal(H_input,H_talking)
    inputStr = 'Nonstationary Narrowband and Broadband Noise';
else
    inputStr = 'Unknown Noise';
end

fig = figure;
subplot(1,2,1)
surf(t_frame,1:HA.Length,H_wts_buf.Buffer')
title({['LMS Filter Convergence with Step Size ' num2str(mu)], ...
    [inputStr,' Input, Estimate of ',pathStr], ...
    ['LMS Filter Length ',num2str(HA.Length)]})
xlabel('Time (s)')
ylabel('Filter taps')
zlabel('Filter coefficients')

%% Experimental Case

% Release all relevant System Objects to ensure FIR filter weights and
% filter states are set to zero, buffers are empty, and signals are at
% their beginning
releaseAll(HPlayer,H_bandpass,H_debussy,H_lowpass,H_noise,H_talking,H_wts_buf,HA)

%%% TOGGLE %%% Filter Length
HA.Length = 50;

%%% TOGGLE %%% Step Size
mu = 0.002;

%%% TOGGLE %%% H_path to point to either the lowpass filter System Object or the
% bandpass filter System Object
H_path = H_lowpass;
% H_path = H_bandpass;

%%% TOGGLE %%% H_input to point to either the white noise signal System Object or
% the ambient talking System Object
H_input = H_noise;
% H_input = H_talking;

while ~isDone(H_debussy)% Keep iterating until clean signal has no more data
    % Get one frame of input noise data (in this case we cannot inline the
    % step(dsp.SignalSource) method because we need that data again to
    % construct d)
    x = step(H_input);
    
    % Construct d by running the path filter on x and adding one frame of
    % clean signal
    d = step(H_path,x)+step(H_debussy);
    
    % Run the LMS filter algorithm for one frame of inputs
    [y,e,w] = step(HA,x,d,mu,false);
    
    % Play one frame of the error signal (estimate of clean signal) with
    % audio device
    step(HPlayer,e)
    
    % Log the estimated FIR filter weights in the buffer System Object
    step(H_wts_buf,w')
end

% Calculate time vector for start of each signal frame
t_frame = (0:(size(H_wts_buf.Buffer,1)-1))*H_debussy.SamplesPerFrame/Fs;

% Visualize estimated FIR filter response vs. time using a surface plot
if isequal(H_path,H_lowpass)
    pathStr = 'Lowpass Filter';
elseif isequal(H_path,H_bandpass)
    pathStr = 'Bandpass Filter';
else
    pathStr = 'Unknown Filter';
end

if isequal(H_input,H_noise)
    inputStr = 'Stationary Broadband Noise';
elseif isequal(H_input,H_talking)
    inputStr = 'Nonstationary Narrowband and Broadband Noise';
else
    inputStr = 'Unknown Noise';
end

figure(fig)
subplot(1,2,2)
surf(t_frame,1:HA.Length,H_wts_buf.Buffer')
title({['LMS Filter Convergence with Step Size ' num2str(mu)], ...
    [inputStr,' Input, Estimate of ',pathStr], ...
    ['LMS Filter Length ',num2str(HA.Length)]})
xlabel('Time (s)')
ylabel('Filter taps')
zlabel('Filter coefficients')

%% Block LMS Filter

releaseAll(HPlayer,H_bandpass,H_debussy,H_lowpass,H_noise,H_talking,H_wts_buf,HA)

HA_block = dsp.BlockLMSFilter;

HA_block.Length = 50;
HA_block.BlockSize = HA_block.Length;
% Block size is typically set to FIR filter length in most implementations
% of the Block LMS algorithm.

HA_block.StepSizeSource = 'Input port';
HA_block.WeightsResetInputPort = true;

% Step Size
mu = 0.0002;
H_path = H_lowpass;pathStr = 'Lowpass Filter';
H_input = H_noise;inputStr = 'Stationary Broadband Noise';

while ~isDone(H_debussy)
    % Get one frame of input noise data (in this case we cannot inline the
    % step(dsp.SignalSource) method because we need that data again to
    % construct d)
    x = step(H_input);
    
    % Construct d by running the path filter on x and adding one frame of
    % clean signal
    d = step(H_path,x)+step(H_debussy);
    % Note that in DSP System Toolbox, the input frame size MUST be an integer
    % multiple of the BlockSize property.
    
    % Run the Block LMS filter algorithm for one frame of inputs
    [y,e,w] = step(HA_block,x,d,mu,false);
    
    % Play one frame of the error signal (estimate of clean signal) with
    % audio device
    step(HPlayer,e)
    
    % Log the estimated FIR filter weights in the buffer System Object
    step(H_wts_buf,w')
end

% Calculate time vector for start of each signal frame
t_frame = (0:(size(H_wts_buf.Buffer,1)-1))*H_debussy.SamplesPerFrame/Fs;

% Visualize estimated FIR filter response vs. time using a surface plot
figure(fig)
subplot(1,2,2)
surf(t_frame,1:HA.Length,H_wts_buf.Buffer')
title({['Block LMS Filter Convergence with Step Size ' num2str(mu)], ...
    [inputStr,' Input, Estimate of ',pathStr], ...
    ['LMS Filter Length ',num2str(HA.Length)]})
xlabel('Time (s)')
ylabel('Filter taps')
zlabel('Filter coefficients')