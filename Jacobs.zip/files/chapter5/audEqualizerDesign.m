%% Solution to the Audio Equalizer design problem
% Please pay attention to the comments and execute one cell at a time.
%
%% Start design by specifying sampling rate, Fs
Fs = 8192;
%% The first band is a lowpass filter
d1 = fdesign.lowpass;
set(d1,'specification') % Look at the command window for choices
%% Choose appropriate specification depending on available information
% Note that appending the sampling rate at the end, turns off the
% normalized frequency mode. Also note that we use 'fdesign.lowpass' again
% to specify the parameters.
d1 = fdesign.lowpass('Fp,Fst,Ap,Ast',130,131,1,40,Fs);
%% Find out what design methods are available for this specification
designmethods(d1,'iir') % Look at the command window for choices
%% Since we only had passband ripple specified, try 'cheby1'
Hd1 = design(d1,'cheby1') %#ok<*NOPTS>
fvt1 = fvtool(Hd1);
%% Check filter structure
info(Hd1)
%% Measure filter performance
measure(Hd1)
%% Find cost for implementation
cost(Hd1)
%% That was a large filter order, try elliptic design
Hd1 = design(d1,'ellip')
setfilter(fvt1,Hd1);
%% Check filter structure
info(Hd1)
%% Measure filter performance
measure(Hd1)
%% Find cost for implementation
cost(Hd1)
%% That was quite good, now design band 2
d2 = fdesign.bandpass
%% The default specification has all we need to specify
% We could use 'fdesign.bandpass' again to specify filter parameters
% d2 = fdesign.bandpass(128,130,260,262,40,1,40,Fs)
% Alternatively, we can use the 'setspecs' command
setspecs(d2,129,130,260,262,40,1,40,Fs);
%% Check if specifications were set correctly
d2
%% Find what design methods are available for our bandpass specification
designmethods(d2,'iir')
%% Design the filter
Hd2 = design(d2,'ellip')
addfilter(fvt1,Hd2);
%% Check filter structure
info(Hd2)
%% Measure filter performance
measure(Hd2)
%% Find cost for implementation
cost(Hd2)
%% Design bands 3 to 5 similarly
d3 = fdesign.bandpass(258,260,520,524,40,1,40,Fs);
d4 = fdesign.bandpass(516,520,1040,1048,40,1,40,Fs);
d5 = fdesign.bandpass(1032,1040,2090,2096,40,1,40,Fs);
Hd3 = design(d3,'ellip');
Hd4 = design(d4,'ellip');
Hd5 = design(d5,'ellip');
addfilter(fvt1,Hd3,Hd4,Hd5);
%% Design the last band, this would be a high pass filter
d6 = fdesign.highpass
%% Again, the default specification is what we want
setspecs(d6,2084,2090,40,1,Fs);
%% Check that the specs have been set correctly
d6
%% Design the filter
Hd6 = design(d6,'ellip');
addfilter(fvt1,Hd6);
%% Check filter structure
info(Hd6)
%% Measure filter performance
measure(Hd6)
%% Find cost for implementation
cost(Hd6)
%% Save the filter designs to Filters.mat
save('Filters.mat','Hd1','Hd2','Hd3','Hd4','Hd5','Hd6');
