% Specify audio file name and get the total number of samples
filename = 'music_ch1.wav';
info = audioinfo(filename);
numSamples = info.TotalSamples;
fs = info.SampleRate;

% Filter coefficients
b = [3.7918e-04, 2.8604e-04, 2.8604e-04, 3.7918e-04];
a = [1, -2.8447, 2.7148, -0.8688];
% Set initial state to zero
filt_state = zeros(1,3);

% Filter audio data in frames of 10000 samples
framesize = 10000;
numFrames = numSamples/framesize;
indx1 = 1;
for frameCount = 1:numFrames
    indx2 = indx1 + framesize - 1;
    yframe = audioread(filename,[indx1, indx2]);
    %soundsc(yframe)
    % Filter the frame of samples keeping track of the filter state
    [yout(indx1:indx2),filt_state] = filter(b,a,yframe,filt_state);
    indx1 = indx1+framesize;
end
% The samples beyond the integer multiple of framesize have been ignored in
% this code. You can add your code here to filter the samples that are left
% out.